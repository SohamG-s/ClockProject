package Patterns;

public class Type4Pattern6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i ,j,k, s,sp;
		sp = 0;
		for(i=5; i>=1;i--) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			k=65;
			for(j=1;j<=i;j++) {
				System.out.print((char)k);
				k++;
			}
			System.out.println();
			sp++;
		}
	}

}
