package Patterns;

public class Type3Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i ,j,s,sp;
		sp=4;
		for(i=1;i<=5;i++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
				for(j=1;j<=i;j++) {
					System.out.print(i);
				}
				System.out.println();
				sp--;
		}
	}

}
