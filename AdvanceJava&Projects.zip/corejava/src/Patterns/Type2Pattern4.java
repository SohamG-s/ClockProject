package Patterns;

public class Type2Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i ,j,k;
		
		k=65;
		for(i=5;i>=1;i--) {
			for(j=1;j<=i;j++) {
				System.out.print((char)k+" ");
				k++;
			}
			System.out.println();
		}
	}

}
