package Patterns;

public class Type5Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,r,s,sp;
		r=9;
		sp=0;
		
		for(i=1;i<=5;i++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(j=1;j<=r;j++) {
				System.out.print("*");
			}
			r=r-2;
			System.out.println();
			sp++;
		}
		
	}

}
