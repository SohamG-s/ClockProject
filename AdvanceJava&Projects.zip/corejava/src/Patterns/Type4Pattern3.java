package Patterns;

public class Type4Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,sp,s;
		sp=0;
		
	for(i=5;i>=1;i--) {
		for(s=1;s<=sp;s++) {
			System.out.print(" ");
		}
		for(j=1;j<=i;j++) {
			System.out.print(j);
			
		}
		System.out.println();
		sp++;
	}
	
	}

}
