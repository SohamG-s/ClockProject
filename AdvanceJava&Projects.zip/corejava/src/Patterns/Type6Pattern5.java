package Patterns;

public class Type6Pattern5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,r,s,sp;
		
		sp=4;
		k=69;
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(i=69;i>=k;i--) {
				System.out.print((char)i);
			}
			for(j=k+1;j<=69;j++) {
				System.out.print((char)j);
			}
			System.out.println();
			sp--;
			k--;
		}
	}

}
