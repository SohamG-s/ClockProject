package Patterns;

public class Type3Pattern5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,s,sp;
		k=65;
		sp=4;
		
		for(i=1;i<=5;i++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(j=1;j<=i;j++) {
				System.out.print((char)k);
			}
			k++;
			System.out.println();
			sp--;
		}
		
	}

}
