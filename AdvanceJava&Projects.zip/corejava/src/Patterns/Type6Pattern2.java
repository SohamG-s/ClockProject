package Patterns;

public class Type6Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,s,sp,r;
		sp=4;
		k=1;
		
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
				
			}
			for(i=1;i<=k;i++) {
				System.out.print(i);
			}
			for(j=k-1;j>=1;j--) {
				System.out.print(j);
			}
			System.out.println();
			sp--;
			k++;
		}
	}

}
