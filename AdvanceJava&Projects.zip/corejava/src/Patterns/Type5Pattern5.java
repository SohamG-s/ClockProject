package Patterns;

public class Type5Pattern5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,r,s,sp,k;
		k=65;
		sp=0;
		
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(i=69;i>=k;i--) {
				System.out.print((char)i);
			}
			for(j=k+1;j<=69;j++) {
				System.out.print((char)j);
			}
			System.out.println();
			k++;
			sp++;
		}
		
	}

}
