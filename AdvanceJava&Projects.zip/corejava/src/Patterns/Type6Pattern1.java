package Patterns;

public class Type6Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,r,s,sp;
		sp=4;
		r=1;
		
		for(i=1;i<=5;i++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(j=1;j<=r;j++) {
				System.out.print("*");
			}
			System.out.println();
			sp--;
			r=r+2;
		}
	}

}
