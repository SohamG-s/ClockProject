package Patterns;

public class Type5Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, j,r,s ,k,sp;
		sp=0;
		k=5;
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
				
			}
			for(j=1;j<=k;j++) {
				System.out.print(j);
			}
			for(j=k-1;j>=1;j--) {
				System.out.print(j);
			}
			sp++;
			k--;
			System.out.println();
		}
	}

}
