package Patterns;

public class Type5Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,s,sp,r;
		k=1;
		sp=0;
		
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" " );
			}
			for(i=5;i>=k;i--) {
				System.out.print(i);
			}
			for(j=k+1;j<=5;j++) {
				System.out.print(j);
			}
			System.out.println();
			sp++;
			k++;
		}
		
	}

}
