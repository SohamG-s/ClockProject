package Patterns;

public class Type5Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i ,j,r,k,s,sp;
		k=69;
		sp=0;
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(i=65;i<=k;i++) {
				System.out.print((char)i);
			}
			for(j=k-1;j>=65;j--) {
				System.out.print((char)j);
				
			}
			sp++;
			k--;
			System.out.println();
		}
	}		

} 
