package Patterns;

public class Type1Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			int i ,j;
		
			for(i=1;i<=5;i++) {     // how many lines 
				for(j=1;j<=i;j++) {   //how many times to  print the star
					System.out.print("*");
					}
				System.out.println();
			}
	}

}
