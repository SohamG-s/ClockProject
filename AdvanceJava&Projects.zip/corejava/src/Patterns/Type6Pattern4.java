package Patterns;

public class Type6Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,r,s,sp;
		
		sp=4;
		k=65;
		
		for(r=1;r<=5;r++) {
			for(s=1;s<=sp;s++) {
				System.out.print(" ");
			}
			for(i=65;i<=k;i++) {
				System.out.print((char)i);
			}
			for(j=k-1;j>=65;j--) {
				System.out.print((char)j);
			}
			System.out.println();
			sp--;
			k++;
		}
	}

}
