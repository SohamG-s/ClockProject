package StringHandling;
import java.util.Scanner;

class Strings {
    int alpha , digits , bs , ss , words , i;
    char ch;
    String st;
    
    Scanner sc = new Scanner(System.in);
    
    public void get() {
        System.out.println("Enter the String");
        st = sc.nextLine(); // Corrected method name to nextLine()
    }
    
    public void set() {
        for (i = 0; i < st.length(); i++) { // Corrected method name to length()
            ch = st.charAt(i); // Corrected parameter to i
            if (ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z') { // Corrected logic and syntax
                alpha++;
            } else if (ch >= '0' && ch <= '9') { // Corrected syntax
                digits++;
            } else if (ch == ' ') { // Corrected syntax
                bs++;
            } else {
                ss++;
            }
        }
        words = bs + 1; // Words count based on spaces
    }
    
    public void display() {
        System.out.println("Digits: " + digits);
        System.out.println("Words: " + words);
        System.out.println("Special Characters: " + ss);
        System.out.println("Alphabets: " + alpha);
        System.out.println("Spaces: " + bs);
    }
}

public class StringCount {
    public static void main(String[] args) {
        Strings obj = new Strings();
        obj.get();
        obj.set();
        obj.display(); // Added call to display method to show results
    }
}
