package StringHandling;

public class StringBuilderDemo {

    public static void main(String[] args) {
        // Create a StringBuilder with initial content "country"
        StringBuilder obj = new StringBuilder("country");
        
        // Append method
        obj.append(" road");
        System.out.println("Append method: " + obj); // Prints "country road"

        // Replace method
        obj.replace(0, 7, "state");
        System.out.println("Replace method: " + obj); // Prints "state road"

        // Delete method
        obj.delete(5, 10);
        System.out.println("Delete method: " + obj); // Prints "state"

        // Reverse method
        obj.reverse();
        System.out.println("Reverse method: " + obj); // Prints "etats"

        // Insert method
        obj.insert(0, "country ");
        System.out.println("Insert method: " + obj); // Prints "country etats"

        // Capacity method
        System.out.println("Capacity method: " + obj.capacity()); // Prints the capacity

        // charAt method
        System.out.println("charAt method: " + obj.charAt(3)); // Prints the character at index 3

        // Length method
        System.out.println("Length method: " + obj.length()); // Prints the length of the string

        // Substring method (start)
        System.out.println("Substring method (start): " + obj.substring(8)); // Prints the substring from index 8

        // Substring method (start, end)
        System.out.println("Substring method (start, end): " + obj.substring(0, 7)); // Prints the substring from index 0 to 7
    }
}
