package StringHandling;
import java.util.Scanner;
class Checkings{
	char  ch;
	int i;
	String st1,st2="";
	Scanner sc = new Scanner(System.in);
	public void get() {
		System.out.println("Enter the string");
		st1=sc.next();
		
	}
	public void set() {
		System.out.println("String is "+ st1);
		for(i=st1.length()-1;i>=0;i--) {
			ch=st1.charAt(i);
			st2=st2+ch;
		}
		if (st1.equalsIgnoreCase(st2)) {
			System.out.println("IT is palindrome");
		}else {
			System.out.println("It is not a palindrome");
		}
	}
	
	
}
public class PalindromeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Checkings obj = new Checkings();
		obj.get();
		obj.set();
	}

}
