package StringHandling;


public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String o2 = new String("Country");
		String o3 = new String("India where is India");

		System.out.println("String is "+o2);
		System.out.println("String is "+o3);
		System.out.println("String lowercase is "+o2.toLowerCase());
		System.out.println("String uppercase is "+o2.toUpperCase());
		System.out.println("String is "+o2.charAt(3));
		System.out.println("String is "+o3.indexOf("is"));
		System.out.println("String is "+o2.compareTo(o3));
		System.out.println("String is "+o2.equals(o3));
		System.out.println("String is "+o2.compareToIgnoreCase(o3));
		System.out.println("String is "+o2.concat(o3));
		System.out.println("String is "+o2.substring(1));
		System.out.println("String is "+o2.substring(2,4));
		System.out.println("String is "+o2.replace('y', 'i'));
		System.out.println("String is "+o2.trim());
		System.out.println("String is "+o2.length());
		System.out.println("String is "+o3.lastIndexOf("is"));




		
	}

}
