package StringHandling;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer obj = new StringBuffer("Churchgate");
		
		System.out.println("The string is"+obj);
	System.out.println("The length of string is"+obj.length());
		System.out.println("The capacity of string is"+obj.capacity());
		//System.out.println("The Append method is"+obj.append("Station"));
		//System.out.println("The Reverse of string is "+obj.reverse());
		System.out.println("The reverse string is"+obj);
		System.out.println("The char at method is"+obj.charAt(3));
		//System.out.println("The Delete method is"+obj.delete(1, 4));
		//obj.setCharAt(1,'c');
		System.out.println("The after using setcharat string is"+obj);
		System.out.println("The replace method for is"+obj.replace(2,3,"abc"));
		System.out.println("The tostring method is"+obj.toString());
	}

}
