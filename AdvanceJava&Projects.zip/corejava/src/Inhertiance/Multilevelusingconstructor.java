package Inhertiance;

class Ab{
	Ab(){
		System.out.println("Default constructor of base class Ab");
	}
	Ab(int n1){
		System.out.println("One parametrized constructor of base class Ab is "+n1);
	}}

	class Bc extends Ab{
		Bc(){
			System.out.println("Default constructor of base class Bc");
		}
		Bc(int n1,int n2){
			super (n1);
		System.out.println("Two parametrized constructor of base class Bc is "+n1+" and "+ n2);
		}
	}
class Cd extends Bc{
	Cd(){
		System.out.println("Default constructor of base class Cd");
	}
	Cd(int n1, int n2, int n3){
		super(n1,n2);
		System.out.println("Three parametrized constructor of base class Bc is "+n1+" and "+ n2+ " and "+n3);
	}
}
public class Multilevelusingconstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cd c = new Cd();
		Cd ca = new Cd (1,2,3);
		
		if (c instanceof Cd) {
			System.out.println("It is object for c");
		}else {
			System.out.println("It is not object for c");
		}
		
	}

}
