package Inhertiance;
class A {
	public void display() {
		System.out.println("parent class a Display()");
	}
	
	}
class B extends A{
	public void show() {
		System.out.println("child class b show()");
}
}
public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj = new B();//upcasting
		
		obj.display();
		
		B objb = (B)obj;  //downcasting
		objb.show();
		
		System.out.println("Narrowing and widening in java");
		double a = 355454.14;
		System.out.println(a);
		int b = (int)a  ;
		System.out.println(b);
		long c = (long )b;
		System.out.println(c);
		
	}
}

