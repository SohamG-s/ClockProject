package Inhertiance;
import java.util.Scanner;

class Company{
	String cname,location;
	int est;
	Scanner sc = new Scanner (System.in);

	public void get() {
		System.out.println("Enter Company name, location, Established");
		cname = sc.next();
		location = sc.next();
		est = sc.nextInt();
	}
	
	public void display() {
		System.out.println("Company name is "+cname);
		System.out.println("Company location is "+location);
		System.out.println("Company established is "+est);
		
	}
}
class Employee extends Company{
	String ename,qualification;
	int age,id;
	
	public void get() {
		 super.get();
		System.out.println("Enter Name,Qualification,age,id");
		ename= sc.next();
		qualification= sc.next();
		age = sc.nextInt();
		id = sc.nextInt();
	}
	
	public void display() {
		super.display();
		System.out.println("Employee name is "+ename );
		System.out.println("Employee qualification is "+qualification );
		System.out.println("Employee age is "+age );
		System.out.println("Employee id is "+id );
		
	}
}
	 class Department extends Employee{
		 String designation,department;
		 int exp;
		 long salary;
		 
		 public void get() {
		 super.get();
			 System.out.println("Enter Designation, Deparment,experience,salary");
			 designation = sc.next();
			 department = sc.next();
			 exp = sc.nextInt();
			 salary = sc.nextLong();
			  }
		 
		 public void display() {
			 super.display();
			 System.out.println("Designation is "+designation);
			 System.out.println("Department is "+department);
			 System.out.println("Experience is "+exp);
			 System.out.println("Department is "+salary);
		 }
	 }
	 
public class MultiLevel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Department o1 = new Department();
		o1.get();
		o1.display();
		
	}

}
