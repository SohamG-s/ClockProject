package Inhertiance;

class Address {
	String city,state,country;
	Address(String city,String state,String country){
		this.city= city;
		this.state = state;
		this.country=country;	
	}
}
class Employeee{
	int id ,age;
	String name;
	Address address;
	Employeee(int id,int age,String name,Address address){
		this.id = id;
		this.age=age;
		this.name= name;
		this.address= address;
	}
	public void display() {
		System.out.println("Employee id is "+id);
		System.out.println("Employee age is "+age);
		System.out.println("Employee name is "+name);
		System.out.println("Employee address is "+address.city+" , "+address.state+" , "+address.country);
	}
}
public class HasA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address obj = new Address("Mumbai","Maharashtra","India");
		Employeee e1 = new Employeee(22,34,"Ramesh",obj);
		e1.display();
		}
	}



