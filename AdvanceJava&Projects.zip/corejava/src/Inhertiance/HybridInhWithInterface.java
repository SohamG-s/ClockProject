package Inhertiance;
import java.util.*;
class Collegess
{
	String cname,location;
	int estyear;
	
	Scanner s=new Scanner(System.in);
	
	public void get()
	{
		System.out.println("enter college name, established year and location");
		cname=s.next();
		estyear=s.nextInt();
		location=s.next();
	}
	
	public void display()
	{
		System.out.println("college name is "+cname);
		System.out.println("college established in year "+estyear);
		System.out.println("college is located at "+location);
	}
}
class Studentss extends Collegess
{
	String sname,degreename;
	int rno,std,degreeyear,semester,corejava,embeddedsystem,computergraphics,cost,softwareengineering;
	public void get()
	{
		super.get();
		System.out.println("enter student name, roll number, degree name, degree year and semester");
		sname=s.next();
		rno=s.nextInt();
		degreename=s.next();
		degreeyear=s.nextInt();
		semester=s.nextInt();
		System.out.println("enter marks obtained in english, physics, chemistry, mathematics, biology and information technology subjects");
		corejava=s.nextInt();
		embeddedsystem=s.nextInt();
		computergraphics=s.nextInt();
		cost=s.nextInt();
		softwareengineering=s.nextInt();
	}
	public void display()
	{
		super.display();
		System.out.println("student name is "+sname);
		System.out.println("degree name is "+degreename);
		System.out.println("degree year is "+degreeyear);
		System.out.println("semester is "+semester);
		System.out.println("student roll number is "+rno);
		System.out.println("marks obtained in core java subject is "+corejava);
		System.out.println("marks obtained in embedded system subject is "+embeddedsystem);
		System.out.println("marks obatined in computer graphics subject is "+computergraphics);
		System.out.println("marks obtained in computer oriented statistical techniques subject is "+cost);
		System.out.println("marks obtained in software engineering subject is "+softwareengineering);
	}
}
interface NCC
{
	public static final String choice="no";
	void show();
}
class Result extends Studentss implements NCC
{
	int total=0;
	double per;
	
	@Override
	public void show() 
	{
		System.out.println("Student has participated in NCC");
	}
	
	public void info()
	{
		super.get();
		super.display();
		if(choice.equalsIgnoreCase("yes"))
		{
			System.out.println("Student has participated in NCC");
			total=corejava+embeddedsystem+computergraphics+cost+softwareengineering+75;
			System.out.println("Total marks obtained is "+total);
			per  =total/6.0;
			System.out.println("Passed "+degreeyear+" year "+semester+" semester successfully with "+per+" percentage");
		}
		else
		{
			System.out.println("Student has not participated in NCC");
			total=corejava+embeddedsystem+computergraphics+cost+softwareengineering;
			System.out.println("Total marks obtained is "+total);
			per=total/5.0;
			System.out.println("Passed "+degreeyear+" year "+semester+" semester successfully with "+per+" percentage");
		}
	}
}
public class HybridInhWithInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Result obj=new Result();
		obj.info();
		//obj.show();
	}
}
