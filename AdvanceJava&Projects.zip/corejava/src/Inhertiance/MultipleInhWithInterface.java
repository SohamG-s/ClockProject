package Inhertiance;
import java.util.Scanner;
class College {
	String name,location;
	int est;
	Scanner sc = new Scanner(System.in);
	
	void get() {
		System.out.println("Enter college details");
		name = sc.next();
		location = sc.next();
		est = sc.nextInt();
	}
	
	void display() {
		System.out.println(name);
		System.out.println(location);
		System.out.println(est);
	}
}


interface Sports{
	public static final String choice = "yes";
	void show(); //It is by default public and abstract method
	
		
	}

class Student extends College implements Sports{
	int rno,std;
	String sname;
	long fees;
	
	 void get() {
		 System.out.println("Enter student details"); 
		 super.get();
		 rno = sc.nextInt();
		 std = sc.nextInt();
		 sname = sc.next();
		 fees = sc.nextLong();
	 }
	 
	 void display() {
		 super.display();
		 System.out.println(rno);
		 System.out.println(std);
		 System.out.println(sname);
		 System.out.println(fees);
		 
	 }
	 public void show() {
		 System.out.println("It is implementation of interface");
	 }
	
}
public class MultipleInhWithInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st = new Student();
		st.get();
		st.display();
		st.show();
	}

}
