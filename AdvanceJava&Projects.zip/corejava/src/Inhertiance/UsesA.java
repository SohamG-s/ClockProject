package Inhertiance;

class Tempo{
	
	int salary = 50000;
}
class Employe{
	public void display() {
		int bonus = 5000;
		Tempo o1 = new Tempo();
		System.out.println("Employee salary is "+o1.salary);
		System.out.println("Employee bonus is "+bonus);
		System.out.println("Total salary is "+( bonus+o1.salary));
	}
}
public class UsesA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employe a = new Employe();
		a.display();
	}

}
