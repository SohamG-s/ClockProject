package Inhertiance;
import java.util.Scanner;

class company1{
	String cname,location;
	int est;
	Scanner sc = new Scanner(System.in);
	
	public void get() {
		System.out.println("Enter Company name ,Established, location ");
		cname=sc.next();
		location = sc.next();
		est=sc.nextInt();
	}
	
	public void display() {
		System.out.println("Company name is "+cname);
		System.out.println("location  is "+location);
		System.out.println("Established in "+est);	
	}	
}
	
class emp1 extends company1{
	int age,id;
	String ename,designation;
	long salary;
	
	public void get() {
		super.get();
		System.out.println("Enter the details for emp");
		id = sc.nextInt();
		age = sc.nextInt();
		ename = sc.next();
		designation = sc.next();
		salary = sc.nextLong();
	}
	
	public void display() {
		super.display();
		System.out.println("Employee id is "+id);
		System.out.println("Employee age is "+age);
		System.out.println("Employee ename is "+ename);
		System.out.println("Employee designation is "+designation);
		System.out.println("Employee salary is "+salary);
		
	}
}
public class SingleLevel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp1 o1 = new emp1();
		o1.get();
		o1.display();
	}

}
