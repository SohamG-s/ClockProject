package Inhertiance;
class Em{
	long a = 50000;//method
	
}


class Is_ARelationship extends Em{
	static 
	long bonus = 3000;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

 Is_ARelationship obj = new Is_ARelationship();
System.out.println(obj.a+obj.bonus);
	}

}
