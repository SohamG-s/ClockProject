package Inhertiance;
import java.util.Scanner;


class Developer{
	Scanner sc = new Scanner(System.in);
	String location, prjname;
	int compyear,totalflrs;
	
	public void get() {
		System.out.println("Enter Location , prjname, compyear, totalflrs");

		location = sc.next();
		prjname = sc.next();
		compyear = sc.nextInt();
		totalflrs = sc.nextInt();
	}
	public void display() {
		System.out.println("Enter location "+location);
		System.out.println("Enter prjname "+prjname);
		System.out.println("Enter compyear "+compyear);
		System.out.println("Enter total floors "+totalflrs);
		
	}
}

class Flat1bhk extends Developer{
	int area , floorno;
	String wing;
	long price;
	
	
	public void get() {
		
		super.get();
		System.out.println("Enter for 1Bhkarea , price, floorno, wi ng");
		 area = sc.nextInt();
		 price = sc.nextLong();
		floorno= sc.nextInt();
		 wing = sc.next();
	}
	public void display() {
		super.display();
		System.out.println("The area is "+area);
		System.out.println("The price is "+price);
		System.out.println("The floorno is "+floorno);
		System.out.println("The wing is "+wing);
		
	}
}
class Flat2bhk extends Developer{
	int area ,floorno;
	String wing;
	long price;
	public void get() {
		System.out.println("Enter  for 2 Bhk area , price, floorno, wing");
		 area = sc.nextInt();
		 price = sc.nextLong();
		 floorno= sc.nextInt();
		 wing = sc.next();
	}
	public void display() {
		System.out.println("The area is "+area);
		System.out.println("The price is "+price);
		System.out.println("The floorno is "+floorno);
		System.out.println("The wing is "+wing);
	}
	
}
class Flat3bhk extends Developer{
	int area,floorno;
	String wing;
	long price;
	public void get() {
		System.out.println("Enter for 3 Bhk area , price, floorno, wing");
		 area = sc.nextInt();
		 price = sc.nextLong();
	floorno= sc.nextInt();
		 wing = sc.next();
	}
	
	public void display() {
		System.out.println("The area is "+area);
		System.out.println("The price is "+price);
		System.out.println("The floorno is "+floorno);
		System.out.println("The wing is "+wing);
	}
	
	
}
public class Hierarchialinheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Flat1bhk o1 = new Flat1bhk();
		o1.get();
		o1.display();
		
		Flat2bhk o2 = new Flat2bhk();
		o2.get();
		o2.display();
		Flat3bhk o3 = new Flat3bhk();
		o3.get();
		o3.display();
		
	}

}
