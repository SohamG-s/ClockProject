package Encapsulation;
import java.util.Scanner;

class Books {
	
	private int isbnn;
	private String title;
	private int price;
	private String author;
	
	
	public Books(int isbnn, String title, int price, String author) {
		
		
		
		
		this.isbnn = isbnn;
		
		
		this.title = title;
		
		this.price = price;
		
		this.author = author;
	}
	
	


	public int getIsbnn() {
		return isbnn;
	}

	public void setIsbnn(int isbnn) {
		this.isbnn = isbnn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	@Override
	public String toString() {
		return "Books [isbnn=" + isbnn + ", title=" + title + ", price=" + price + ", author=" + author + "]";
	}
	
	
	
}
public class ConstructorUserinput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		
		System.out.print("Enter the ISBN number: ");
		
		int isbnn=sc.nextInt();

		System.out.print("Enter the Title: ");
		String title=sc.next();
        
		System.out.print("Enter the Price: ");
		int price = sc.nextInt();
        
		System.out.print("Enter the Author: ");
		String author = sc.next();
		
		Books o1 = new Books (isbnn,title,price,author);
		
		o1.setPrice(450);
		o1.setTitle("Tiger");
		
		System.out.println(o1.getIsbnn());
		System.out.println(o1.getTitle());
		System.out.println(o1.getPrice());
		System.out.println(o1.getAuthor());

		
		
		
		
		System.out.println("Book details");
		System.out.println(o1);
		
	}

}
