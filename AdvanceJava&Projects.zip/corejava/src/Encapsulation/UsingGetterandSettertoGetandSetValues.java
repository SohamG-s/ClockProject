package Encapsulation;
	
class Student{
	
	private String name;
	private int rollno;
	private String std;
	
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	
	
	
}
public class UsingGetterandSettertoGetandSetValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st = new Student();
		st.setName("Soham"); 
		st.setRollno(45);
		st.setStd("Ty.Btech");
		
		System.out.println("The name is "+st.getName());
		System.out.println("The roll no is "+st.getRollno());
		System.out.println("The std is "+st.getStd());
	}

}
