package Packages;

import static java.lang.System.*;

import static java.lang.Math.*;


class Inbuilt{
	
	public void display() {
		out.println("Java programming");
		out.println("abs method "+abs(-5));
		out.println("ceil method "+ceil(6.7));
		out.println("Max method "+max(4,7));
		out.println("Min method "+min(6,3));
		out.println("power method "+pow(8,3));
		out.println("Sqrt method "+sqrt(9));
		out.println("floor method "+floor(7.3));
 
  
	}
}
public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inbuilt obj = new Inbuilt ();
		obj.display();
	}

}
