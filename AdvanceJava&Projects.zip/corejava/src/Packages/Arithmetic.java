package Packages;

public class Arithmetic {
    int add = 0;

    public void Addition(int num1, int num2) {
        add = num1 + num2;
        System.out.println(add);  // Print result directly in the method
    }

    int subtract;

    public void Subtraction(int num1, int num2) {
        subtract = num1 - num2;
        System.out.println(subtract);  // Print result directly in the method
    }

    int mul = 1;

    public int Multiplication(int num1, int num2) {
        mul = num1 * num2;
        return mul;
    }

    double mod;

    public double Modulus(int num1, int num2) {
        mod = num1 % num2;
        return mod;
    }

    double div;

    public double division(int num1, int num2) {
        div=(num1/num2); 
          return div;  
           
        }
       
    }

