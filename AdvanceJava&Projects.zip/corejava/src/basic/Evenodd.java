package basic;
import java.util.Scanner;
public class Evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		System.out.println ("The number is :");
		Scanner sc = new Scanner (System.in);
		number = sc.nextInt();
		
		if (number%2==0) {
			System.out.println("The " + number + " is a even no");
		}
		if (number%2!=0) {
			System.out.println("The " + number + " is a odd no");
		}
		
		
	}

}
