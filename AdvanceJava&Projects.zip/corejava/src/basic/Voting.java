package basic;
import java.util.Scanner;
public class Voting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the age :");
		age = sc.nextInt();
		if ( age <18 ) {
			System.out.println("The "+age+ " is not Eligible for voting");
		}
		else{
			System.out.println("The "+age+ " is Eligible for voting");
		}
		
	}

}
