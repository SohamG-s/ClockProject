package basic;
import java.util.Scanner;
public class Weekdays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int day;
		 System.out.println("Enter the day");
		 Scanner sc = new Scanner(System.in);
		 day = sc.nextInt();
		 if (day ==1) {
			 System.out.println("IT is monday");
			 
		 }
		 else if(day ==2) {
			 System.out.println("It is tueday");
			 
		 }
		 else if (day == 3) {
			 System.out.println("It is wednesday");
			 
		 }
		 else if (day ==4) {
			 System.out.println("It is thurday");
			 
		 }
		 else if (day ==5) {
			 System.out.println("it is friday");
		 }
		 else if(day ==6) {
			 System.out.println("it is saturday");
			 
		 }
		 else if (day ==7 ) {
			 System.out.println("it is sunday");
		 }
		 else {
			 System.out.println("enter the day between 1 to 7");
		 }
	}

}
