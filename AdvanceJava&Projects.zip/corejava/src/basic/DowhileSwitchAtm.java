package basic;
import java.util.Scanner;

public class DowhileSwitchAtm {

    public static void main(String[] args) {
        String custname, bankname;
        long balance, withdraw, deposit;
        int atmpin, oldatmpin1, oldatmpin2, choice, newatmpin;
        
        balance = 100000;
        String cont = "yes"; 
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the custname, bankname, atmpin:");
        custname = sc.next();
        bankname = sc.next();
        atmpin = sc.nextInt();
        
    do {
            System.out.println("Enter 1. to view balance amount");
            System.out.println("Enter 2. to withdraw amount");
            System.out.println("Enter 3. to deposit amount");
            System.out.println("Enter 4. to change ATM pin");
            System.out.println("Enter your choice for ATM transaction:");
            choice = sc.nextInt();
            
            if (atmpin == 1234) {
                System.out.println("Welcome");
                switch (choice) {
                    case 1: 
                        System.out.println("Balance: " + balance);
                        break;
                    case 2:  
                        System.out.println("Enter the withdraw amount:");
                        withdraw = sc.nextLong();
                        if (withdraw < balance) {
                            balance = balance - withdraw;
                            System.out.println("New balance: " + balance);
                        } else {
                            System.out.println("Insufficient balance");
                        }
                        break;
                    case 3:
                        System.out.println("Enter the deposit amount:");
                        deposit = sc.nextLong();
                        balance = balance + deposit;
                        System.out.println("New balance: " + balance);
                        break;
                 case 4: 
                        System.out.println("Enter the old ATM pin twice:");
                        oldatmpin1 = sc.nextInt();
                        oldatmpin2 = sc.nextInt();
                        if (oldatmpin1 == oldatmpin2) {
                            System.out.println("Enter new pin:");
                            newatmpin = sc.nextInt();
                            atmpin = newatmpin;
                            System.out.println("ATM pin changed successfully");
                        } else {
                            System.out.println("Invalid old pin");
                        }
                        break;
                    default: 
                        System.out.println("Invalid choice");
                }
            } else {
                System.out.println("Invalid ATM pin");
            }
            
            System.out.println("Do you want to perform another transaction? (yes/no)");
            cont = sc.next();
            
        } while (cont.equalsIgnoreCase("yes"));
        
        sc.close();
    }
}
