package basic;
import java .util.Scanner;
public class Smallest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1, n2 , n3;
		Scanner sc = new Scanner (System.in);
		System.out.println("The smallest number is :");
		n1 = sc.nextInt();
		n2 = sc.nextInt();
		n3 = sc.nextInt();
		
		
		
		if (n1<n2 && n1<n3){
			System.out.println(n1 + " is the smallest number");
			}
	
		if (n2<n1 && n2<n3){
			System.out.println(n2 + " is the smallest number");
			}
		if (n3<n1 && n3<n2){
			System.out.println(n3 + " is the smallest number");
			}
	
	}

}
