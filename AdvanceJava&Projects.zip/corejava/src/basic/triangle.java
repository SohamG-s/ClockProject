package basic;
import java.util.Scanner;
public class triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double base,height,formula;
		  System.out.println("Enter base and height:");
		Scanner sc = new Scanner (System.in);
		
		 base = sc.nextDouble();
		 height = sc.nextDouble();
		 
		 System.out.println("enter base and height "+base +"," +height);
		 formula = 0.5* base * height;
		System.out.println("triangle calculation is "+ formula);
		
		
	}

}
