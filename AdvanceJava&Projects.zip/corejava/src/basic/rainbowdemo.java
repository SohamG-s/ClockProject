package basic;
import java.util.Scanner;
public class rainbowdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int rainbowcolor;
		 System.out.println("enter the color number");
		 Scanner sc = new Scanner(System.in);
		 rainbowcolor= sc.nextInt();
		 if (rainbowcolor ==1 ) {
			 System.out.println("it is violet");
			 
		 }
		 else if (rainbowcolor ==2) {
			 System.out.println("it is indigo");
			 
		 }
		 else if (rainbowcolor ==3) {
			 System.out.println("it is blue");
		 }
		 else if (rainbowcolor ==4) {
			 System.out.println("it is green");
		 }
		 else if (rainbowcolor ==5) {
			 System.out.println("it is yellow");
		 }
		 else if (rainbowcolor ==6) {
			 System.out.println("it is orange");
		 }
		 else if (rainbowcolor ==7) {
			 System.out.println("it is red");
		 }
		 else {
			 System.out.println("Enter the number bet 1 to 7");
		 }
	}

}
