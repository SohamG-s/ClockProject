package basic;
import java.util.Scanner;
public class Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	int n;
		n = sc.nextInt();
		switch(n) {
		case 1 : System.out.println("hello");
		break;
		case 2 : System.out.println("khalo");
		break;
		case 3 : System.out.println("nalo");
		break;
		case 4 : System.out.println("khelo");
		break;
		default: System.out.println("invalid");
		break;
		}
	}

}
