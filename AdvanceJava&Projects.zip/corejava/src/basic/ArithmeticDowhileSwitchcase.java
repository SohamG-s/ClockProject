package basic;
import java.util.Scanner;
public class ArithmeticDowhileSwitchcase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1 , n2,add = 0, sub=0,mul,choice;
		double div,mod;
	 String	cont ;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the numbers");
		n1= sc.nextInt();
		n2 = sc.nextInt();
		System.out.println("First number"+n1);
		System.out.println("Second number"+n2);
		
		do {
			System.out.println("enter 1 to add");
			System.out.println("enter 2 to sub");
			System.out.println("enter 3 to mul");
			System.out.println("enter 4 to div");
			System.out.println("enter 5 to mod");
			
			System.out.println("Enter the choice");
			choice=sc.nextInt();
			System.out.println("Your choice is "+ choice);
			
			switch(choice){
				case 1: add= n1+n2;
				System.out.println(add);				break;
				case 2 : sub = n1-n2;
				System.out.println(sub);
				break;
				case 3: mul = n1*n2;
				System.out.println(mul);
				break;
				case 4: div = n1/n2;
				System.out.println(div);
				break;
				case 5: mod = n1%n2;
				System.out.println(mod);
				break;
				default:System.out.println("Invalid");
				
			}
		cont= sc.next();
		}while(cont.equalsIgnoreCase("yes"));
	}

}
