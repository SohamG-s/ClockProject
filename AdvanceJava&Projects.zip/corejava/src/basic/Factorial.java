package basic;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i, fact = 1, n;
		System.out.print("ENter the n");
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		for(i=n; i>1;i--) {
			fact = fact *i;
			
		}
		System.out.println("The factorial is "+ fact+ "for"+n);
	}

}
