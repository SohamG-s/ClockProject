package basic;
import java.util.Scanner;
public class cubex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int side, formula;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Cube value :");
		side = sc.nextInt();
		System.out.println("Enter the Value "+ side);
		formula = side * side *side;
		System.out.println("The final value is "+ formula);
	}

}
