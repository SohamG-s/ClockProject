package basic;
import java.util.Scanner;
public class Cuboid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int length, width, height, formula;
		
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter the Value :");
		length = sc.nextInt();
		width = sc.nextInt();
		height = sc.nextInt();
		
		System.out.println("THe values are "+ length+","+width+","+height);
		formula = length *width *height;
		System.out.println("The final value is "+ formula);
		
	}

}
