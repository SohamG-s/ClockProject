package basic;
import java.util.Scanner;
public class Vowelconsonentusinguserinput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ch;
		System.out.println("Enter any character");
		Scanner sc = new Scanner (System.in);
		ch = sc.next();
		
		if(ch.equalsIgnoreCase("a")|| ch.equalsIgnoreCase("e")||ch.equalsIgnoreCase("i")||ch.equalsIgnoreCase("o")||ch.equalsIgnoreCase("u")) {
			
			System.out.println("The character is vowel");
			
		}
		else 
		{
			System.out.println("it is a consonent");
		}
		
		
	}

}
