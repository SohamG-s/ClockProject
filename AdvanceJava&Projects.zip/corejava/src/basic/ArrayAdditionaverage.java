package basic;
import java.util.Scanner;
public class ArrayAdditionaverage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[50];
			int i,n,sum=0;
			double avg;
			System.out.println("Enter the number in arrays");
			Scanner sc = new Scanner(System.in);
			n = sc.nextInt();
			
			
			System.out.println("Enter "+n+" Elements in array");
			
			for(i=0;i<=n-1;i++) {
				a[i]=sc.nextInt();
			}
			System.out.println("Array elements are as follows");
			
			for(i=0;i<=n-1;i++) {
				System.out.println(" "+a[i]);
			}
			for(i=0;i<=n-1;i++) {
				sum= sum+a[i];
			}
			System.out.println("sum of arrays is "+sum);
			avg = sum/n;
			System.out.println("The average is "+avg);
					
	}
 
}
