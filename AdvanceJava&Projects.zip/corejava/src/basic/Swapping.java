package basic;
import java.util.Scanner;
public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a,b,t;
		System.out.println("Enter any two numbers");
		Scanner sc= new Scanner (System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("Before Swapping "+ a+"and"+b);
// 	t = a
		//a= b      (with third variable)
			//	b=t
		a = a+b;
		b = a-b ;   // without third variable
		a = a-b;
		System.out.println ( "After swapping "+a+","+b);
		
	}

}
