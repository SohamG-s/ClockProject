package basic;
import java.util.Scanner;
public class Reverseofarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int [40];
		int i , n, t;
		System.out.println("Enter the input");
		Scanner sc = new Scanner(System.in);
		n= sc.nextInt();
		System.out.println("the elements as follows");
		
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();	
		}
		System.out.println("Reverse elements are as follows");
		for(i=n-1;i>=0;i--) {
			
			while(a[i]!=0) {
				t=a[i]%10;
				System.out.print(" "+t);
				a[i]=a[i]/10;
			}
		}
		
		
	}

}
