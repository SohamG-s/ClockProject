package basic;
import java.util.Scanner;
public class Matrixmultiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]=new int [25][25];
		int b[][]=new int [25][25];
		int c[][]=new int [25][25];
		int i , n,m,j,p,q,k;
		 
		 System.out.println("Enter the input");
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Matrix A");
		 m=sc.nextInt();
		 n=sc.nextInt();
		 System.out.println("Enter "+m*n+" elements");
		 for(i=0;i<m;i++){
			 for(j=0;j<n;j++) {
				 
				 a[i][j]=sc.nextInt();
			 }
		 }
		 System.out.println("Matrix as follows");
		 for (i=0;i<m;i++) {
			  for(j=0;j<n;j++) {
				  System.out.print(" "+a[i][j]);
			  }
			  System.out.println();
		 }
		 System.out.println("Enter the matrix b");
		 p= sc.nextInt();
		 q=sc.nextInt();
		 System.out.println("Enter "+p*q+" elements");
		 for(j=0;j<p;j++) {
			 for(k=0;k<q;k++) {
				 b[j][k]=sc.nextInt();
				 }
		 }
		 System.out.println("Matrix b as follows");
		 for(j=0;j<p;j++) {
			 for(k=0;k<q;k++) {
				 System.out.print(" "+b[j][k]);
			 }
			 System.out.println();
			 }
		 if(n==p) {
			 for(i=0;i<m;i++) {
				 for(k=0;k<q;k++) {
					 
					 c[i][k]=0;
				 }
			 }
			 for(i=0;i<m;i++) {
				 for(j=0;j<n;j++) {
					 for(k=0;k<q;k++) {
						 c[i][k]=c[i][k]+a[i][j]*b[j][k];
					 }
				 }
			 }
			 System.out.println("Matrix multiplication result is");
			 for(i=0;i<m;i++) {
				 for(k=0;k<q;k++) {
					 System.out.print(" "+c[i][k]);
				 }
				 System.out.println();
			 }
		 }
	}

}
