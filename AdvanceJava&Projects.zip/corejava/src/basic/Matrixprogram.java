package basic;
import java.util.Scanner;
public class Matrixprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]= new int[40][40];
		int i ,m,n,j;
		System.out.println("Enter the input");
		Scanner sc= new Scanner(System.in) ;
		m = sc.nextInt();
		n= sc.nextInt();
		System.out.println("Enter "+m*n+" elements");
		
		for(i=0;i<m;i++) {
			for(j=0;j<n;j++) {
				
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("The matrix elements are as follows");
		for(i=0;i<m;i++) 
		{
			for(j=0;j<n;j++) 
			{
				System.out.print(" "+a[i][j]);
			}
			System.out.println();
		}
		
		
		}
	}


