package basic;
import java.util.Scanner;
public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int i , limit, a =0 ,b = 1,c= 1;
 System.out.println("Enter the number");
 Scanner sc = new Scanner (System.in);
 limit = sc.nextInt();
 
 for (i = 0; i<limit;i++) {
	
	System.out.println(c);
    c=a+b;
	a=b;
	b=c;
 }
 
 
 }

}
