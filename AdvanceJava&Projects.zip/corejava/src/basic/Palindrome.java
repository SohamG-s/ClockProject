package basic;
import java.util.Scanner;
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int   n ,rev=0,t, num;
		System.out.println("enter the no");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		num=n;
		
		while(n!=0)
		{
			t = n%10;
			rev = (rev*10)+t;
			n=n/10;
		}
		if (num==rev) {
			System.out.println("IT is a palindrome");
		}
		else {
			System.out.println("it is not a palindrome");
		}
		
	}

}
