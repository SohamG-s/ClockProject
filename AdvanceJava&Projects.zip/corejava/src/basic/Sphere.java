package basic;
import java.util.Scanner;
public class Sphere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Double radius,formula;
		Scanner sc = new Scanner (System.in);
		System.out.println("The radius given :");
		radius = sc.nextDouble();
		System.out.println("Enter the radius "+ radius);
		formula = 1.333*3.14*radius*radius*radius;
		System.out.println("The final calculation is "+ formula);
	}

}
