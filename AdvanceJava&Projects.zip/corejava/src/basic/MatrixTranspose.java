package basic;
import java.util.Scanner;
public class MatrixTranspose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]= new int[25][25];
		int d[][]= new int [25][25];
		int i ,m, n,j;
		 System.out.println("Enter the input");
		 Scanner sc = new Scanner(System.in);
		 m=sc.nextInt();
		 n= sc.nextInt();
		 System.out.println("Enter "+m*n+" elements");
		 for(i=0;i<m;i++)
		 {
			 for(j=0;j<n;j++)
			 {
				 a[i][j]=sc.nextInt();
			 }
		 }
		 System.out.println("Matrix elements are as follows");
		 for(i=0;i<m;i++)
		 {
			 for(j=0;j<n;j++) 
			 {
				 System.out.print(" "+a[i][j]);
			 }
			 System.out.println();
		 }
		 for(j=0;j<n;j++) 
		 {
		for(i=0;i<m;i++) 
		{ 
		d[j][i]=a[i][j];	
		}
		 }
		 System.out.println("Transpose matrix A is");
		 for(i=0;i<m;i++) 
		 {
			 for(j=0;j<n;j++)
			 {
			System.out.print(" "+d[i][j]);	 
			 }
			 System.out.println();
		 }
	}

}
