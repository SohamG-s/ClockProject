package basic;
import java.util.Scanner;
public class Findelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[30];
		int i , n , num;
		 boolean cont = false ;
		System.out.println("Enter the number of elements");
		Scanner sc = new Scanner (System.in);
		n = sc.nextInt();
		//System.out.println("Enter the elements");
		
		for(i = 0;i<n;i++) {
			a[i]=sc.nextInt();
			System.out.println("The elements are "+a[i]);
		}
		//System.out.println("The elements are"+a[i]);
		num= sc.nextInt();
		for(i=0;i<n;i++) {
			if(a[i]==num) {
				cont = true;
			}
		}
		if(cont==true)
		{
			System.out.println(num+" is present");	
		}
		else
		{
			System.out.println("not present");
		}
		
	}

}
