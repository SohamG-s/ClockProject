package basic;
import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n ,sum=0,t,num;
		Scanner sc = new Scanner(System.in);
	
		
		n = sc.nextInt();
		System.out.println("The original no is "+n);
		num=n;
		while(n!=0){
			t=n%10;
					sum=sum+(t*t*t);
					n=n/10;
			
		}
		if(num==sum) {
			System.out.println("It is armstrong no");
		}
		else {
			System.out.println("it is not an armstrong no");
		}
		
	}

}
