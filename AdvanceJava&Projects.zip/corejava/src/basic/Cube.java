package basic;
import java.util.Scanner;
public class Cube {//Class is CIRCLE

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double radius, volume;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter radius of circle ");
		radius = s.nextDouble();
		System.out.println("radius  of circle is "+radius);
		volume =3.14*radius*radius;
		System.out.println("volume of radius is "+volume);
	}

}
