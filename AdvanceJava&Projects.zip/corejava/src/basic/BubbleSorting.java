package basic;
import java.util.Scanner;
public class BubbleSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int[40];
		int i , n, j,t;
		System.out.println("Enter the values");
		Scanner sc = new Scanner (System.in);
		n = sc.nextInt();
		
		System.out.println(" no as follows");
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		for(i=0;i<n-1;i++) {
			for(j=0;j<n-1;j++) {
				if(a[j]>a[j+1]) {
					
					
			//swapping	
					t=a[j];
					a[j]=a[j+1];
					a[j+1]=t;
				}
			}
		}
		System.out.println("After sorting elements");
		for(j=0;j<n;j++) {
			System.out.print(" "+a[j]);
		}
	}

}
