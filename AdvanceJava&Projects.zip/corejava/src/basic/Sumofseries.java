package basic;
import java.util.Scanner;
public class Sumofseries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int i,sum = 0 , limit;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the number");
			limit = sc.nextInt();
			for (i = 1; i<=limit;i++) {
				sum = sum+i;
				
			}
			System.out.println("The total sum is "+ sum+" for "+limit );
			
	}

}
