package basic;
import java.util.Scanner;
public class largestnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n1, n2 , n3 , n4;
		Scanner sc = new Scanner(System.in);
		n1 = sc.nextInt();
		n2 = sc.nextInt();
		n3 = sc.nextInt();
		n4 = sc.nextInt();
		System.out.println(n1+ "is the first number" );
		System.out.println(n2+ "is the second number" );
		System.out.println(n3+ "is the third number" );
		System.out.println(n4+ "is the fourth number" );
		
		if (n1>n2 && n1>n3 && n1>n4) {
			System.out.println(n1 + "is greater number  ");
		}
		else if (n2>n1 && n2>n3 && n2>n4) {
			System.out.println(n2 + "is greater number  ");
			
		}
		else if (n3>n1 && n3>n2 && n3>n4) {
			System.out.println(n3 + "is greater number  ");
		}
		else if (n4>n1 && n4>n2 && n4>n3) {
			System.out.println(n4 + "is greater number  ");
	}

	}
}
