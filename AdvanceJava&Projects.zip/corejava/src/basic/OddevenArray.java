package basic;
import java.util.Scanner;
public class OddevenArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int [40];
		int even[]= new int [25];
		int odd[]= new int [25];
		
		int i , n ;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the input");
		n=sc.nextInt();
		//System.out.println("Enter the input");
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();
			
		}
		System.out.println("the elements are");
		for(i=0;i<n;i++) {
			even[i]=0;
			}
		for(i=0;i<=n;i++) {
			odd[i]=0;
		
		}
		for(i=0;i<n;i++) 
		{
			if(a[i]%2==0) 
			{
				even[i]=a[i];
			}
			else {
				odd[i]=a[i];
			}
		}
		System.out.println("Even array elements are as follows");
		for(i=0;i<n;i++) {
			System.out.println(" "+ even[i]);
		}
		System.out.println("odd");
		for(i=0;i<n;i++) {
			System.out.println(" "+odd[i]);
		}
	}

}
