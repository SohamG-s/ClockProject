package basic;

public class Iterative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		System.out.println("Enter the numbers form 1 to 10 ");
		for (i=1; i<=10;i++) {
			System.out.println(i);
		}
		System.out.println("smallest to highest");
		for(i=10; i>=1;i--) {
			System.out.println(i);
		}
		
	}

}
