package basic;
import java.util.Scanner;

public class Matrixaddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a [][]=new int [25][25];
		int b [][]=new int [25][25];
		int c [][]= new int [25][25];
		
		int i,m, n, p,q,j;
		System.out.println("Enter the input");
		Scanner sc = new Scanner(System.in);
		m= sc.nextInt();
		n=sc.nextInt();
		System.out.println("Enter "+m*n+" elements");
		
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++) {
				a[i][j]=sc.nextInt();
				
			}
		}
		System.out.println(" "+"Matrix elements are as follows");
		for(i=0;i<m;i++)
		{
		for(j=0;j<n;j++)
		{
			System.out.print(" "+a[i][j]);
		}
		System.out.println();
		}
		System.out.println("Enter the matrix b");
		p=sc.nextInt();
		q=sc.nextInt();
		System.out.println("Enter "+p*q+" elements");
		for(i=0;i<p;i++) 
		{
			for(j=0;j<q;j++) {
				b[i][j]=sc.nextInt();
				
			}
		}
		System.out.println(" "+"Matrix elements are as follows");
		for(i=0;i<p;i++) 
		{
			for(j=0;j<q;j++)
			{
			System.out.print(" "+b[i][j]);	
			}
			System.out.println();
		}
		if(m==p && n==q)
			
		{
			
			for(i=0;i<m;i++)
			{
				
				for(j=0;j<n;j++)
				{
					
					c[i][j]=0;
				}
			}
			for(i=0;i<m;i++){
				for(j=0;j<n;j++) {
					c[i][j]=b[i][j]+a[i][j];
				}
				
			}
			System.out.println("Matric addition is");
			for(i=0;i<m;i++) 
			{
				for(j=0;j<n;j++) {
					System.out.print(" "+c[i][j]);
				}
				System.out.println();
			}
		}
		else {
			System.out.println("The martrix input is not valid");
		}
	}

}
