package basic;
import java.util.Scanner;

public class Reverseno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,t ;
		System.out.println("Enter the no");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		System.out.println("The original no is "+n);
		System.out.println("The Reverse no is ");
	int i ;
	while (n!=0) {
		t=n%10;
		System.out.print(t);
		n=n/10;
	}
	
	
	
	
	
	
	}

}
