package basic;
import java.util.Scanner;
public class Cylinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Double radius,height,formula;
		
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter the Cylinder value:");
		radius = sc.nextDouble();
		height = sc.nextDouble();
		
		System.out.println("Enter the radius and height "+ radius +","+height);
		formula = 3.14* radius *radius *height;
		System .out.println("The final value is "+ formula);
		
	}

}
