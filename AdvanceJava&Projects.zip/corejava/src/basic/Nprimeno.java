package basic;
import java.util.Scanner;
public class Nprimeno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i, n, x = 1;
	        Scanner sc = new Scanner(System.in);
	        n = sc.nextInt();
	        sc.close(); // Close the scanner to prevent resource leaks
	        
	        while (n != 0) {
	            x++;
	            i = 2;
	            while (x % i != 0) {
	                i++;
	            }
	            if (x == i) {
	                System.out.println(x);
	                n--;
	            }
	        }
	    }
	}