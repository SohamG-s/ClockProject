package basic;

import java.util.Scanner;
import Packages.Arithmetic;

public class ImportpPackage {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1, num2;

        System.out.println("Enter the numbers:");
        num1 = sc.nextInt();
        num2 = sc.nextInt();

        Arithmetic o1 = new Arithmetic();

        System.out.println("The Calculations are:");

        o1.Addition(num1, num2);

        System.out.println("For subtraction is:");
        o1.Subtraction(num1, num2);

       // System.out.println("For multiplication:");
        int mulResult = o1.Multiplication(num1, num2);
        System.out.println("Multiplication is: " + mulResult);

        System.out.println("Enter for modulus:");
        double modResult = o1.Modulus(num1, num2);
        System.out.println("Modulus is: " + modResult);

        sc.close();
    }
}
