package basic;
import java.util.Scanner;

public class Maxelementsinarray {

    public static void main(String[] args) {
        
        int i, n, max;
        
        
      
        int[] a = new int[50];
        
       
        Scanner sc = new Scanner(System.in);

       
        System.out.println("Enter the number");
        n = sc.nextInt();
        
        
        for (i = 0; i <=n; i++) {
            a[i] = sc.nextInt();    
        }
        
      
      //  System.out.println("Array elements are as follows:");
        //for (i = 0; i <= n; i++) {
          //  System.out.println(a[i]);
        //}
        
        
       max = a[0];
        
       
        for (i = 0; i <= n; i++) { // Start from 0 to include the first element in comparisons
            if (a[i] > max) {
                max = a[i];
            }
        }
        
       
        System.out.println("The maximum element in the array is: " + max);
    }
}
