package basic;

public class Primeno1to100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i ,j;
		for(i=2;i<=100;i++) {
			
			for(j=2;j<i;j++) {
				
				if(i%j==0) {
					break;
				}
		}
		
		
			if (i==j) {
				System.out.println(i);
			}
		}
		
	}

}
