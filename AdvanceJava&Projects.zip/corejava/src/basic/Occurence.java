package basic;
import java.util.Scanner;
public class Occurence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[40]; 
		int i , n , num, count=0;
		 System.out.println("Enter the input ");
		 Scanner sc = new Scanner (System.in);
		 n= sc.nextInt();
		 
		 System.out.println("Enter the elements in array");
		 for(i=0;i<=n;i++) {
			 a[i]=sc.nextInt();
			 }
		 num=sc.nextInt();
	   System.out.println("Enter an element whose occurence is to be found"+num);
	   for(i=0;i<=n;i++) {
		   
		   if(num==a[i]) {
			   count++;
		   }
		   if(count>0) {
			   System.out.println("The "+count+" for "+num);
		   }
		   else {
			   System.out.println("not valid");
		   }
	   }
		 
	
	
	}

}
