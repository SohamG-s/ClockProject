package basic;
import java.util.Scanner;
public class Mathematicaltable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i , n;
		System.out.println("Enter the n :");
		Scanner sc = new Scanner (System.in);
		n = sc.nextInt();
		
		for(i=1;i<=10;i++) {
			System.out.println(n+" X "+i+" = "+n*i);
		}
	}	

}
