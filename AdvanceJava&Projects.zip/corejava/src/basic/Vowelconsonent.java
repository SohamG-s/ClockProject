package basic;

public class Vowelconsonent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char wo = 's';
		 System.out.println("The word is : " +wo);
		 if (wo=='a'|| wo=='e'||wo=='i'||wo=='o'||wo=='u'|| wo=='A'||wo=='E'||wo=='I'||wo=='O'||wo=='U') {
			 System.out.println(wo + " is a vowel");
			 }
		 else {
			System.out.println(wo + " It is a consonent"); 
		 }
	}

}
