package basic;
import java.util.Scanner;
public class Identifynum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("The number given is :") ;
        n = sc.nextInt();
        
       if (n>0) {
    	   System .out.println  ("\n"+n+ "\t is positive num");
    	   
       }
	if (n <0 ) {
		System.out.println("\n"+n+"\t is a negative num");
		
	}
	if (n==0) {
		System.out.println("\n" +n+"\t is equal");
	}
       
       
	}
	
}
