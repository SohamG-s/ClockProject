package basic;
import java.util.Scanner;
public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int length, breadth,formula;
		
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter length and Breadth");
		length = sc.nextInt();
		breadth = sc.nextInt();
		System.out.println("horizontal value and vertical value "+length+","+breadth);
		formula = length *breadth;
			System.out.println("The rectangle calculation is "+ formula);	
	}

}
