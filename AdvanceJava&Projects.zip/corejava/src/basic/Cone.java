package basic;
import java.util.Scanner;
public class Cone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Double radius, height, formula;
		System.out.println("The given value is : ");
		Scanner sc = new Scanner (System.in);
		radius = sc.nextDouble();
		height = sc.nextDouble();
		System.out.println("Enter the Radius and Height "+radius +"," +height);
		formula = 0.333*3.14*radius *radius* height;
		System.out.println("The final calculation is "+ formula);
		
	}

}
