package basic;
import java.util.Scanner;
public class square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int side,formula;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the side of square ");
		side = sc.nextInt();
		System.out.println("side of square is "+side);
		formula = side *side ;
		System.out.println("The square is "+formula);
		
		
	}

}
