package basic;
import java.util.Scanner;

public class IdentifyPrimeornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,b=2;
		System.out.println("Enter the number:");
		Scanner sc = new Scanner(System.in);
		n= sc.nextInt();
		System.out.println("Original no "+n);
		
		while(n%b!=0)
		{
			b++; 
			
		}
		if(n==b) {
			System.out.println("it is a prime no");
		}
		else {
			System.out.println ("it is not a prime no");
		}
	}

}
