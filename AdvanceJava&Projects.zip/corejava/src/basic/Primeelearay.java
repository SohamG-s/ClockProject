package basic;
import java.util.Scanner;

public class Primeelearay {

    public static void main(String[] args) {
        int a[] = new int[50];
        int i, n, b;
        System.out.println("Enter the number");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        
        for (i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }
        
        System.out.println("array elements are as follows");
        for (i = 0; i < n; i++) {
            b = 2;
            while (a[i] % b != 0) {
                b++;
            }
            if (a[i] == b) {
                System.out.println(a[i] + " is a prime no");
            } else {
                System.out.println(a[i] + " is not a prime no");
            }
        }
        
        sc.close();
    }
}
