package JDBC;
import java.sql.*;
public class JDBCInsertDeleteUpdateUsingExecuteUpdateMethod {

	public static void main(String[] args) throws ClassNotFoundException{
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","8886soham");
			Statement st = con.createStatement();
			//String query = "INSERT INTO EMPLOYEE values(1118,'Sohamsakpal',24,'IT','Java Developer',3,80000)";
     		//String query1 = "DELETE FROM EMPLOYEE WHERE ID = 1118";
     		String query2 ="UPDATE EMPLOYEE set name = 'Don',salary=45000 where id =1118";
			int result = st.executeUpdate(query2);
			 
			if (result == 1) {
				//System.out.println("Record Inserted");
				//System.out.println("Record Deleted");
				System.out.println("Record Updated");
			}else {
				System.out.println("Record not Inserted");
				
			}
		}catch (SQLException e) {
			System.out.println(e);
		}
		
	}

}
