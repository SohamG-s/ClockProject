package JDBC;
import java.sql.*;
public class EntireJDBC {

	public static void main(String[] args) throws ClassNotFoundException{
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcc","root","8886soham");
			Statement  st = con.createStatement();
			
			
			String query10 = "Select * from Students";
			ResultSet rs = st.executeQuery(query10);
			ResultSetMetaData rsmd = rs.getMetaData();
			
			String c1 = rsmd.getColumnName(1);
			String c2 = rsmd.getColumnName(2);
			String c3 = rsmd.getColumnName(3);
			String c4 = rsmd.getColumnName(4);
			String c5 = rsmd.getColumnName(5);
			String c6 = rsmd.getColumnName(6);
			
			System.out.println(c1+"\t"+c2+"\t"+c3+"\t"+c4+"\t"+c5+"\t"+c6+"\t");
			
			
			
			while (rs.next()) {
				int rollno = rs.getInt("Rollno");
				String name = rs.getString("Name");
				int age = rs.getInt("Age");
				String coursename = rs.getString("Coursename");
				String city = rs.getString("City");
				int fees= rs.getInt("Fees");
				
				System.out.println(rollno+"\t"+name+"\t"+age+"\t"+coursename+"\t"+city+"\t"+fees+"\t");
				
			}
			System.out.println("Displayed");
			
			
//			String query1 = "INSERT INTO STUDENTS values(44,'Soham',13,'java','thane',350)";
//			String query2 = "INSERT INTO STUDENTS values(33,'Raju',15,'c++','kalyan',250)";
//			String query7 = "UPDATE Students set name = 'Don' where rollno =44";
//			String query8 = "UPDATE Students set name = 'Kapil' where rollno =45";
//			String query9 = "Delete from Students where rollno =33"; 
//			//String query3 = "INSERT INTO STUDENTS values(45,'rani',12,'Evs','Diva',150)";
//			st.execute(query7);
//			st.execute(query8);
//			st.execute(query9);
//			
//			System.out.println("Record Inserted");
			
			
//			String query4= "INSERT INTO STUDENTS values(46,'Lakshman',15,'History','Kopar',450)";
//			String query5= "INSERT INTO STUDENTS values(57,'kamlesh',20,'Dotnet','Kalyan',650)";
//			String query6= "INSERT INTO STUDENTS values(43,'Lakshman',16,'c','Kopar',850)";
//			String query22 ="UPDATE Students set name = 'Updated' where rollno =57";
//			String query24 ="UPDATE Students set name = 'Updated' where rollno =43";
//			String query23 = "UPDATE Students set name = 'Updated' where rollno =46";
//			String query26 = "Delete from Students where rollno =46"; 
			
//			PreparedStatement ps1 = con.prepareStatement(query22);
//			PreparedStatement ps2 = con.prepareStatement(query24);
//			PreparedStatement ps3 = con.prepareStatement(query26);
//			ps1.execute();
//			ps2.execute();
//			ps3.execute();
			
//			System.out.println("Updated");
			//System.out.println("Record Inserted");
			
			st.close();
			con.close();
			rs.close();
			
		}catch(SQLException e ) {
			System.out.println(e);
		}
		
	}

}
