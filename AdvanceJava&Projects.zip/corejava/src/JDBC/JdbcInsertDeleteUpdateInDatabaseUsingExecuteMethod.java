package JDBC;
import java.sql.*;
public class JdbcInsertDeleteUpdateInDatabaseUsingExecuteMethod {

	public static void main(String[] args)throws ClassNotFoundException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","8886soham");
			Statement  st = con.createStatement();
			
			String query = "INSERT INTO EMPLOYEE (1117,'Sohamsakpal',24,'IT','Java Developer',3,80000)";
			//String query1 = "DELETE FROM EMPLOYEE WHERE ID = 1117";
			//String query2 = "UPDATE EMPLOYEE set name = 'Don',salary=45000 where id =1117";
			st.execute(query);
			
			System.out.println("Record INSERTED");
			//System.out.println("Record UPDATED");
			//System.out.println("Record DELETED");
			st.close();
			con.close();
			
			
		}catch(SQLException e) {
			System.out.println(e);
		}
	}

}
