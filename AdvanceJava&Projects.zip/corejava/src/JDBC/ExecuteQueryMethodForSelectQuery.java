package JDBC;
import java.sql.*;
public class ExecuteQueryMethodForSelectQuery {

	public static void main(String[] args) throws ClassNotFoundException{
		// TODO Auto-generated method stub
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","8886soham");
			Statement  st = con.createStatement();
			
			String query1 = "Select * from employee";
			ResultSet rs = st.executeQuery(query1);
			ResultSetMetaData rsmd = rs.getMetaData();
			
			String c1 = rsmd.getColumnName(1);
			String c2 = rsmd.getColumnName(2);
			String c3 = rsmd.getColumnName(3);
			String c4 = rsmd.getColumnName(4);
			String c5 = rsmd.getColumnName(5);
			String c6 = rsmd.getColumnName(6);
			String c7 = rsmd.getColumnName(7);
			
			System.out.println(c1+"\t"+c2+"\t"+c3+"\t"+c4+"\t"+c5+"\t"+c6+"\t"+c7+"\t");
			
			while(rs.next()){
				int id = rs.getInt("Id");
				String name = rs.getString("Name");
				int age = rs.getInt("Age");
				String department = rs.getString("Department");
				String designation = rs.getString("Designation");
				int experienece = rs.getInt("Experienece");
				int Salary = rs.getInt("Salary");
				
				System.out.println(id+"\t"+name+"\t"+age+"\t"+department+"\t"+designation+"\t"+experienece+"\t"+Salary+"\t");
			}
			
			
			rs.close();
			st.close();
			con.close();
			System.out.println("Connection Closed");
		
		
		
		}catch(SQLException e) {
			System.out.println(e);
		}
	}

}
