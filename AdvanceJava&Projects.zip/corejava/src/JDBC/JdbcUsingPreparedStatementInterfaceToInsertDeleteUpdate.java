package JDBC;
import java.sql.*;
import java.util.*;

import com.mysql.cj.xdevapi.PreparableStatement;
	
public class JdbcUsingPreparedStatementInterfaceToInsertDeleteUpdate {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","8886soham");
			Scanner sc = new Scanner(System.in);
			System.out.println("INSERT data");
			int id,age,experience,salary;
			String name,department,designation; 
			
			id = sc.nextInt();
			name= sc.next();
			age = sc.nextInt();
			department  = sc.next();
			designation = sc.next();
			experience= sc.nextInt();
			salary = sc.nextInt();
			String sql = "INSERT into Employee values(?,?,?,?,?,?,?)";
			PreparedStatement ps= con.prepareStatement(sql);
			
		ps.setInt(1,id);
		ps.setString(2,name);
		ps.setInt(3,age);
		ps.setString(4,department);
		ps.setString(5,designation );
		ps.setInt(6,experience);
		ps.setInt(7,salary);
		
		ps.execute();
		System.out.println("Record Inserted");
		
//			System.out.println("Enter Updating values");
//		int age,salary,id;
//		age= sc.nextInt();
//		salary= sc.nextInt();
//		id = sc.nextInt();
//			
//		String sql1 = "UPDATE employee set age=?,salary=? where id= ? ";
//		PreparedStatement ps1 = con.prepareStatement(sql1);
//		ps1.setInt(1, age);
//		ps1.setInt(2, salary);
//		ps1.setInt(3,id);
//		
//		ps1.execute();
//		
//		System.out.println("Record updated");
//		
//		
		
//			String sql2= "DELETE from employee where id=?";
//			PreparedStatement ps2 = con.prepareStatement(sql2);
//			ps2.setInt(1,222);
//			int i = ps2.executeUpdate();
//			System.out.println(i+"Record deleted");
//			
			
		}catch(SQLException e) {
			System.out.println(e);
		}
	}

}
