package MultiThreading;

class Bank extends Thread {
    int amount = 10000;

    public void run() {
        synchronized(this) {
            withdraw(5000);
            deposit(10000);
        }
    }

    public synchronized void withdraw(int amount) {
        if (this.amount < amount) {
            System.out.println("Balance is less");
        } else {
            this.amount = this.amount - amount;
            System.out.println(amount + " Withdraw completed, balance is " + this.amount);
        }
    }

    public synchronized void deposit(int amount) {
        this.amount = this.amount + amount;
        System.out.println(amount + " deposited, new balance is " + this.amount);
    }
}

public class SynchronizationBank{
    public static void main(String[] args) {
        Bank obj = new Bank();
        System.out.println("Initial balance amount is " + obj.amount);
        obj.start();
    }
}
