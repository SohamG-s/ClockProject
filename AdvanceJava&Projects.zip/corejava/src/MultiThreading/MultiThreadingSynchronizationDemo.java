package MultiThreading;



class MyThread extends Thread {
    public void run() {
        synchronized (this) {
            display();
        }
    }
    

    public synchronized void display() {
        String[] msg = {"I", "am", "learning", "java"};
        for (int i = 0; i < msg.length; i++) {
            System.out.println(Thread.currentThread().getName() + " : " + msg[i]);
            try {
                Thread.sleep(2500); // Sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}
public class MultiThreadingSynchronizationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  MyThread t1 = new MyThread();
	        MyThread t2 = new MyThread();

	        t1.setName("First");
	        t2.setName("Second");

	        System.out.println("First thread name is " + t1.getName());
	        System.out.println("Second thread name is " + t2.getName());
	        System.out.println("The priority of thread 1 is " + t1.getPriority());
	        System.out.println("The priority of thread 2 is " + t2.getPriority());

	        t1.start();
	        // Using isAlive() to check if the threads are alive
	        System.out.println("Is alive method for thread1 is " + t1.isAlive());
	       
	        t2.start();
	        System.out.println("Is alive method for thread2 is " + t2.isAlive());
	    }
	}

