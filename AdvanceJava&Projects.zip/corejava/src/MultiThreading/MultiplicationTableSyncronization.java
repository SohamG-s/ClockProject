package MultiThreading;

class table {
    public synchronized void tablemethod(int num) {
        int i;
        for (i = 1; i <= 10; i++) {
            System.out.println(num + " X " + i + " = " + (num * i));
            try {
                Thread.sleep(1000); // Sleep for 2 seconds (2000 milliseconds)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Thread1 extends Thread {
    table t;

    Thread1(table t) {
        this.t = t;
    }

    public void run() {
        t.tablemethod(6);
    }
}

class Thread2 extends Thread {
    table t;

    Thread2(table t) {
        this.t = t;
    }

    public void run() {
        t.tablemethod(9);
    }
}

public class MultiplicationTableSyncronization {
    public static void main(String[] args) {
        table ta = new table();
        Thread1 t1 = new Thread1(ta);
        t1.start();
        Thread2 t2 = new Thread2(ta);
        t2.start();
    }
}
