package MultiThreading;

class RailwayBooking extends Thread {
    int total = 0;

    public void run() {
        int i;
        for (i = 1; i <= 10; i++) {
            total = total + 100;
        }
    }
}

public class InterThreadCommunication {

    public static void main(String[] args) throws InterruptedException {
        RailwayBooking obj = new RailwayBooking();
        obj.start();
        synchronized (obj) {
            obj.wait();
            obj.notifyAll();
            System.out.println("Total price of railway ticket is " + obj.total + " Rs");
        }
    }
}
