package MultiThreading;

class Multithreading extends Thread{
	public void run(){
		int i;
		for(i=1;i<=5;i++) {
			System.out.println("Multithreading for i "+i);
		}
	}
}
public class Multithreadingdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Multithreading obj = new Multithreading();
			obj.start();
			
			int j;
			for(j=1;j<=5;j++) {
				System.out.println("Multithreading for j"+j);
			}
	}

}
