package MultiThreading;

class Multithreadingde extends Thread{
	public void run() 
	{
		try {
			int i;
			for(i = 1;i<=5;i++) {
				System.out.println("Multi Method "+i);
				Thread.sleep(4000);	
		}
		
		}catch(InterruptedException u) {
			System.out.println(u);
		}
	
	}
}
public class MultithreadingSleepMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multithreadingde obj = new Multithreadingde();
		obj.start();
		
		try {
			int j;
			for(j= 1;j<=5;j++) {
				System.out.println("Main method "+j);
				Thread.sleep(5000);
			}
		}
		catch(InterruptedException e) {
			System.out.println(e);
		}
	}

}
