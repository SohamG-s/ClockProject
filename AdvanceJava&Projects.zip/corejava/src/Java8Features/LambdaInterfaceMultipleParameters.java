package Java8Features;
import java.util.*;

interface addition{
	
	void addit(int n1,int n2);
	}

interface subtraction{
	void subit(int n1,int n2);
}
interface multiplication{
	void mult(int n1,int n2);
	
}
interface modulus{
	void mod(int n1 , int n2);
	
}
interface division{
	void div (int n1, int n2);
}

public class LambdaInterfaceMultipleParameters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any two numbers ");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
	 
		System.out.println("The numbers are "+num1 +" " + num2);
		
		addition refad = (n1,n2)->{
			int add = 0;
			add = n1+n2;
			System.out.println("Addition "+add);
		};
		refad.addit(num1,num2);
		
		subtraction subtr= (n1,n2)->{
			
			int sub = 0;
			sub = n1 - n2;
			System.out.println("Subtraction "+sub);
		};
		subtr.subit(num1,num2);
		
		multiplication multr   = (n1, n2)->{
			int mul;
			mul = n1 *n2;
			System.out.println("Multiplication "+mul);
		};
		multr.mult(num1,num2);
		
	 modulus modlt  = (n1,n2)->{
		 int mod ;
		 mod =  n1%n2;
		 System.out.println(mod);
	 };
	 modlt.mod(num1, num2);

	 division divi = (n1,n2)->{
		 int div;
		 div = n1/n2;
		 System.out.println(div);
	 };
	 divi.div(num1, num2);
	 
}
}