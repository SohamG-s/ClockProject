package Java8Features;
interface LambdaParameter{
	void show(String name);
}
public class LambdaExpressionWithONEParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LambdaParameter ref =(na)->{
			System.out.println("IT consist one parameter");
			System.out.println("Welcome "+na);
		};
		ref.show("Soham");
		
	}

}
 