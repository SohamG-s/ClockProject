package Java8Features;
import java.util.*;
public class ForEachLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>o = new ArrayList<Integer>();
		o.add(1);
		o.add(2);
		o.add(3);
		
		
		System.out.println("For each Loop");
		
		for(Integer o1 : o) {    //introduced in java 5
			System.out.println(o1);
		}
		
	}

}
