package Java8Features;

interface MyInterface{
	
	default  void display() {
		System.out.println("It is display method");
	}
	
	public static void show() {
		System.out.println("It is show method");
	}
	
	 void okay();
}

class Implementation implements MyInterface{
	public void okay() {
		System.out.println("Implementation of okay");
	}
}

public class UsingDefaultAndStaticMethodinInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyInterface o1 = new Implementation();
		MyInterface.show();
		o1.display();
		o1.okay();
	}

}
