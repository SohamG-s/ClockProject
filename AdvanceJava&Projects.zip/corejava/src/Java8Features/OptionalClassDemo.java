package Java8Features;
import java.util.*;
public class OptionalClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String words[] = new String[20];
		words[5]="Java";
		Optional<String>op  = Optional.ofNullable(words[5]);
		
		if(op.isPresent()) {
			String word = words[5].toLowerCase();
			System.out.println(word);
		}else
			System.out.println("null");
		
		 
		 
	}

}
