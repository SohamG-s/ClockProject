package Java8Features;

public class OptionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String words[] = new String[20];
String word = words[5].toLowerCase();
 System.out.println(word);
	}

}
