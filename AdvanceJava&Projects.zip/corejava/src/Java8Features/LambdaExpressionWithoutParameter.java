package Java8Features;
interface Lambdainterface{
	
	void display();
	
	


}
public class LambdaExpressionWithoutParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Lambdainterface ref =()->{
			System.out.println("This is implementation for display();");
		};
		ref.display();
	}

} 
 