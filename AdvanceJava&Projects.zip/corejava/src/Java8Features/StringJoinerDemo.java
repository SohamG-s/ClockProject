package Java8Features;
import java.util.*;
public class StringJoinerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//StringJoiner obj = new StringJoiner(",");
StringJoiner obj = new StringJoiner(",","[","]");
//StringJoiner obj= new StringJoiner(",","{","}");
//StringJoiner obj = new StringJoiner(":","[","]");

obj.add ("1");
obj.add ("2");
obj.add ("3");
obj.add ("4");

System.out.println(obj);

	}

}
