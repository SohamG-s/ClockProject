package Java8Features;

import java.time.*;
public class DateTimeApI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate ld =  LocalDate.now();
		System.out.println("todays date is "+ld);
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println("Date and Time is "+ldt); 
	
		LocalDateTime obj = ldt.withDayOfMonth(3).withYear(2023);
		System.out.println("Specific date with current time "+obj);
		
		LocalDate ref = LocalDate.now(ZoneId.of("Asia/Kolkata"));
		System.out.println("Date in Ist is "+ref);
		
		LocalDate ref1 = LocalDate.ofYearDay(2017, 100);
		System.out.println("100th day of year 2-16 is "+ref1);
		
		LocalTime lti = LocalTime.of(12,20,25);
		System.out.println("Specific time is "+lti);
		
		LocalTime lt2 = LocalTime.now(ZoneId.of("Asia/Kolkata"));
		System.out.println("Time in Ist is "+lt2);
		
		LocalTime lt3 = LocalTime.ofSecondOfDay(5000);
		System.out.println("1000th seconds time is "+lt3);
		
		LocalDateTime refldt = LocalDateTime.of(2017,Month.OCTOBER,1,10,10,30);
		System.out.println();
	}

}
