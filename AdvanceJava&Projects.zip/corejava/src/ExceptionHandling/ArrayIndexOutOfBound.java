package ExceptionHandling;

public class ArrayIndexOutOfBound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			int arr[]=new int[10];
			System.out.println(arr[15]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		
	}
 
}
