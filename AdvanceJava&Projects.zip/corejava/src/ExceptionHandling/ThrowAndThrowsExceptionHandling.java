package ExceptionHandling;
import java.util.Scanner;
class Less18Exception extends Exception
{
	private static final long serialversionUID =1L;
	String st;
	Less18Exception(String msg){
		st = msg;
	}
	public String toString() {
		return "Less18Exception[" + st + "]";
	}
}
class CheckAge{
	public void checkage(int personage)throws Less18Exception{
		if(personage<18) {
			throw new Less18Exception("You are not eligible for voting");
		}
		else {
			System.out.println("You are eligible for Voting");
		}
	}
}
public class ThrowAndThrowsExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age ;
		Scanner s = new Scanner (System.in);
		System.out.println("Enter your age");
		age=s.nextInt();
		CheckAge obj = new CheckAge();
		try {
			obj.checkage(age);
		}
		catch(Less18Exception e ) {
			System.out.println(e);
		}
	}

}
