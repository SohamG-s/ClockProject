package ExceptionHandling;

public class TryWithMultipleCatch {

    public static void main(String[] args) {
        int a[] = {5, 10};
        int b = 5;
        try {
          int x = a[1] / (b - a[0]);
            // int num = a[6]; // Commented out as it will throw ArrayIndexOutOfBoundsException
            // a[0] = 7.5; // Commented out as it is a type mismatch
            // int a = 10, b = 5, c = 5; // Commented out as 'a' is already defined
            // int c = 5; // Use a different variable name
            // int z = a / (b - c); // Commented out as it will throw ArithmeticException
            int arr[] = new int[10];
            System.out.println(arr[20]); // Commented out as it will throw ArrayIndexOutOfBoundsException
            Object p[] = new Double[5];
            p[1] = 10; // Commented out as it will throw ArrayStoreException
        } 
        catch (Exception ex) {
            System.out.println(ex);
       } 
//        catch (ArrayIndexOutOfBoundsException ae) {
//            System.out.println(ae);
//        }
//        catch (ArrayStoreException as) {
//            System.out.println(as);
//        }
       
        
    }
}
 