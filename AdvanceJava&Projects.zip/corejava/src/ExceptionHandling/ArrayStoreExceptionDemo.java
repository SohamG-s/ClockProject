package ExceptionHandling;

public class ArrayStoreExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Object a[] = new String[10];
			a[0]=9;
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}

}
