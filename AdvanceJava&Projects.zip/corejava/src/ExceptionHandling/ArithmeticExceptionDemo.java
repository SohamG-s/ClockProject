package ExceptionHandling;


public class ArithmeticExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =10,b=5,c=5,z;
		
		try {
			z=a/(b-c);
		}
		catch(ArithmeticException e){
			System.out.println(e);
		}
		finally{
			b=7;
			z=a/(b-c);
			System.out.println("final answer is "+z);
		}
	}

}
