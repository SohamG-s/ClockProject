package ExceptionHandling;

class Ae implements Runnable{
	public void run() {
		try {
			int i ;
			for(i=1;i<=5;i++) {
				System.out.println("Multithreading "+i);
				Thread.sleep(3000);
		}
		
		}
		catch (InterruptedException e) {
			System.out.println(e);
		}
	}
}
public class MultithreadingUsingRunnableWithTryandCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ae obj = new Ae();
		Thread o1 = new Thread(obj);
		o1.start();
		try {
			int j ;
			for(j=1;j<=5;j++) {
				System.out.println("Main method "+j);
				Thread.sleep(4000);
		}
		
		}catch(InterruptedException u){
			System.out.println(u);
		}
	}

}
