package ExceptionHandling;

public class NumberFormatException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int k = Integer.parseInt("50");
			System.out.println("Value of k is "+k);
			int a = Integer.parseInt("java");
		}
		catch (Exception e){
			System.out.println(e);
		}
	}

}
