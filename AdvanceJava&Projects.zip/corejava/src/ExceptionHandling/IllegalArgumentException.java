package ExceptionHandling;

public class IllegalArgumentException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 try {
			 Thread t = new Thread();
			 t.setPriority(11);
		 }
		 catch (Exception e) {
			 System.out.println(e);
		 }
	}

}
