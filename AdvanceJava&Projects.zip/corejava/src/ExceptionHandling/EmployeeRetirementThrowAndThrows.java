package ExceptionHandling;
import java.util.Scanner;
class RetirementException extends Exception{
	String st;
	RetirementException(String msg){
		st=msg;
	}
	public String toString() {
		return "RetirementException [" +st+ "]";
	}
}

class Retirement {
	public void retirecheck (int personage)throws RetirementException{
		if(personage>60) {
			throw new RetirementException("Incategory for Retirement");
		}
		else {
			System.out.println("Left few more y ears");
		}
		
	}
}
public class EmployeeRetirementThrowAndThrows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in); 
		int age;
		 System.out.println("Enter age for Retirement check");
		 age = sc.nextInt();
		 Retirement obj = new Retirement();
		 try {
			 obj.retirecheck(age);

		 }
		 catch (RetirementException e) { 
			 System.out.println(e);
		 }

	}
}