package ExceptionHandling;

class MultithreadingRunnable implements Runnable
{
	public void run() {
		int i;
		for(i = 1 ;i<=5;i++) {
			System.out.println("Multi Method " +i);
		}
	}
}
public class MultithreadingUsingRunnableInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultithreadingRunnable obj = new MultithreadingRunnable();
		Thread o1 = new Thread(obj);
       o1.start();
		int j ;
		 for(j=1;j<=5;j++) {
			 System.out.println("main "+j);
		 }
	}

}
