package ExceptionHandling;

import java.util.Scanner;
class BloodDonationException extends Exception {
	private static final long serialVersionUID = 1L;
	String st;
	 BloodDonationException(String msg) {
		st = msg;
	}
	public String toString() {
		return "BloodDonationException - " +st;
	}
	
}
 
class BloodDonation
{
	public void check (int personage,double personweight)throws BloodDonationException
	{
		if(personage>18 && personage<50 && personweight > 70.0){
			System.out.println("you are eligible for blood donation");
		}
		else {
			throw new BloodDonationException("You are not eligible for blood donation");
		}
	}
}

public class ThrowAndThrowsBloodDonation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		double weight;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your age and weight");
		age=s.nextInt();
		weight = s.nextDouble();
		BloodDonation obj = new BloodDonation();
		try {
			obj.check(age,weight);
			
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}

}
