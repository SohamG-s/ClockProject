package CollectionFramework;
import java.util.*;
public class SortedSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet<String>o= new TreeSet<String>();
		o.add("Hello");
		o.add("Raju");
		o.add("Soham");
		o.add("Xyaa");
		
		System.out.println(o);
		System.out.println("First Method "+o.first());
		System.out.println("Last method "+o.last());
		System.out.println("HeadSet method "+o.headSet("Xyaa"));
		System.out.println("Tailset method "+o.tailSet("Hello"));
		System.out.println("Subset method "+o.subSet("Hello","Xyaa"));
	}

}
