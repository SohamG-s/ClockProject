package CollectionFramework;
import java.util.*;
public class ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List <String>l1 = new ArrayList<String>();
		l1.add("Ramesh");
		l1.add("Suresh");
		l1.add("haresh");
		l1.add("Raju");
		l1.add("Ram");

		
		List<String>l2 = new LinkedList<String>();
		l2.add("Java");
		l2.add("python");
		l2.add("c");
		
		System.out.println("Elements are as follows");
		
		Iterator<String> o1 = l1.iterator();
		while(o1.hasNext()) {
			System.out.println(o1.next()+" ");
		}
		
		Iterator<String>o2=l2.iterator();
		while (o2.hasNext()) {
			System.out.println(o2.next()+" ");
		}
		
		ListIterator<String>o3= l1.listIterator(l1.size());
		while(o3.hasPrevious()) {
			System.out.println(o3.previous()+" ");
		}
		
		ListIterator<String>o4 = l2.listIterator(l2.size());
		while(o4.hasPrevious()) {
			System.out.println(o4.previous()+" ");
		}
		
	}

}
