package CollectionFramework;
import java.util.*;
public class SortedMapInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedMap<Integer,String>o1= new TreeMap<Integer,String>();
		
		o1.put(2,"Soham");   //put method
		o1.put(3, "Tejas");
		o1.put(1, "Rahul");
		
		for(Map.Entry<Integer, String>o:o1.entrySet()) {
			System.out.println(o.getValue()+o.getKey());
					
		}
		
		System.out.println("First Key method "+ o1.firstKey());
		System.out.println("Last Key method "+ o1.lastKey() );
		System.out.println("HeadMap method "+ o1.headMap(3) );
		System.out.println("TailMap  method "+ o1.tailMap(1) );
		System.out.println("SubMap method "+ o1.subMap(1,3) );


	}

}
