package CollectionFramework;

 class Comparabledemo implements Comparable<Comparabledemo> {
    int id, age;
    String name;

    Comparabledemo(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Comparabledemo o) {
        if (this.getAge() == o.getAge()) {
            return 0;
        } else if (this.getAge() > o.getAge()) {
            return 1;
        } else {
            return -1;
        }
    }
}

public class ComparableInt {
    public static void main(String[] args) {
        Comparabledemo e1 = new Comparabledemo(100, "Rajesh", 30);
        Comparabledemo e2 = new Comparabledemo(101, "Kamlesh", 35);
        Comparabledemo e3 = new Comparabledemo(101, "raju", 35);

        int result = e3.compareTo(e2);

        switch(result) {
            case -1:
                System.out.println(e2.getName() + " is elder than " + e3.getName());
                break;
            case 1:
                System.out.println(e3.getName() + " is elder than " + e2.getName());
                break;
            default:
                System.out.println(e3.getName() + " and " + e2.getName() + " are of the same age");
        }
    }
}
