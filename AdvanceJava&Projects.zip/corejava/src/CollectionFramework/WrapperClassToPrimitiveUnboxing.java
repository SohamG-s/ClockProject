package CollectionFramework;

public class WrapperClassToPrimitiveUnboxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i = Integer.valueOf(43);
		Double d = Double.valueOf(7.8);
		
		int a= i.intValue();
		System.out.println("Value for int "+a);
		double o = d.doubleValue();
		System.out.println("Value for double "+o);
		
		
		
		//Unboxing
		
		Integer into = Integer.valueOf(45);
		int n = into;
		System.out.println(into);
		
		Double b = Double.valueOf(33);
		double di =b;
		System.out.println(di);

	}

}
