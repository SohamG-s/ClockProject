package CollectionFramework;
import java.util.*;
public class PriorityQueueUsingQueueInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String>o = new PriorityQueue<String>();
		
		o.add("HII");
		o.add("Bye");
		o.add("Okay");
		
		Iterator<String> o1= o.iterator();
	
		while(o1.hasNext()){ 
			System.out.println(o1.next());
			}
		
		
		
	}

}
