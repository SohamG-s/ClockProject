package CollectionFramework;
import java.util.*;
public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet <String>o1 = new TreeSet<String>();
		
		o1.add("S");
		o1.add("R");
		o1.add("A");
		
		Iterator <String>o2 = o1.iterator();
		
		while(o2.hasNext()) {
			System.out.println(o2.next());
		}
	}

}
