package CollectionFramework;
import java.util.*;
public class DequeInterfaceUsingArrayDeque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<String>o1 = new ArrayDeque<String>();
		
		o1.add("Ram");
		o1.add("Raju");
		o1.add("okay");
		
		o1.addFirst("Sam");
	o1.addLast("sir");	
	System.out.println("OFferFirst"+o1.offerFirst("hii"));
	System.out.println("OfferLast"+o1.offerLast("bye"));
	System.out.println("getFirst"+o1.getFirst());
	System.out.println("getlast"+o1.getLast());
	System.out.println("peekFirst"+o1.peekFirst());
	System.out.println("peeklast"+o1.peekLast());
	System.out.println("removeFirst"+o1.removeFirst());
	System.out.println("removeLast"+o1.removeLast());
	System.out.println("pollFirst"+o1.pollFirst());
	System.out.println("pollLAst"+o1.pollLast());

		
		
		Iterator <String>o3 = o1.iterator() ;
		
		while(o3.hasNext()) {
			System.out.println(o3.next());
			
			
			
		}
	}

}
