package CollectionFramework;
import java.util.*;
public class StackClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String>o1 = new Stack<String>();
		
		o1.push("Soham");
		o1.push("Hello");
		o1.push("Rahul");
		o1.push("Raj");
		
		Iterator<String>o2= o1.iterator();
		while(o2.hasNext()) {
			System.out.println(o2.next());
		}
		
		System.out.println("Pop method "+o1.pop());
		System.out.println("Peek  method "+o1.peek());
		System.out.println("Empty method "+o1.empty());
		System.out.println("Pop method "+o1 .search("Hello"));

	}

}
