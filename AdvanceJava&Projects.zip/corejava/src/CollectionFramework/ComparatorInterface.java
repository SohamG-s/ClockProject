package CollectionFramework;
import java.util.Comparator;

class Employer {
    
    int id, age;
    String name;
    
    Employer(int id, int age, String name) {
        this.id = id;
        this.age = age;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

class Comparatordemo implements Comparator<Employer> {

    @Override
    public int compare(Employer o1, Employer o2) {
        if (o1.getAge() == o2.getAge()) {
            return 0;
        } else if (o1.getAge() > o2.getAge()) {
            return 1;
        } else {
            return -1;
        }
    }
}

public class ComparatorInterface {

    public static void main(String[] args) {
        Employer emp1 = new Employer(101, 30, "Rakesh");
        Employer emp2 = new Employer(102, 32, "Kamlesh");
        
        Comparatordemo comparator = new Comparatordemo();
        
        int result = comparator.compare(emp1, emp2);
        
        switch(result) {
            case -1:
                System.out.println(emp2.getName() + " is elder than " + emp1.getName());
                break;
            case 1:
                System.out.println(emp1.getName() + " is elder than " + emp2.getName());
                break;
            default:
                System.out.println(emp1.getName() + " is the same age as " + emp2.getName());
        }
    }
}
