package CollectionFramework;
import java.util.*;
public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String>o1 = new HashSet<String>();
		o1.add("Ram");
		o1.add("Raju");
		o1.add("kaju");
		
		System.out.println("Elements as follows");
		
		Iterator o2 = o1.iterator();
		
		while(o2.hasNext()) {
			System.out.println(o2.next());
		}
	}

}
