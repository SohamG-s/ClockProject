package CollectionFramework;

public class WrapperClassDemoAutoboxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 2;
		double b = 3.4;
		
		Integer obj =  Integer.valueOf(a);
		System.out.println("The value for Integer  is "+a);
		Double aobj =  Double.valueOf(b);
		System.out.println("The value for Double is "+b);

		if(obj instanceof Integer) {
			System.out.println("It is instance of Integer");
		}
		if(aobj instanceof Double) {
			System.out.println("It is instance of Double");
	}
		
		//Autoboxing 
	int u = 10;
	Integer num=u;
	System.out.println("Wrapper Integer class " +u);
	double m = 4.5;
	Double val = m;
	System.out.println("Wrapper Double class " +m);

	
	}
}
