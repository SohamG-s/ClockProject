package CollectionFramework;
import java.util.*;
public class LinkedHashMapClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap<Integer,String>o1= new LinkedHashMap<Integer,String>();
		o1.put(1, "Soham");
		o1.put(2, "Rahul");
		o1.put(3, "Hello");
		
		System.out.println("The elements are as follows");
		
		for(Map.Entry<Integer, String>o2:o1.entrySet()) {
			System.out.println(o2.getKey()+o2.getValue());

		}
				
	}

}
