package CollectionFramework;
import java.util.*;
public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String>o1 = new HashMap<Integer,String>();
		
		o1.put(1, "c");
		o1.put(2, "j");
		o1.put(3, "j");
		
		System.out.println("Hashmap key and value as follows");
		
		for(Map.Entry<Integer, String>m:o1.entrySet()) {
			System.out.println(m.getKey()+m.getValue());
		}
		
		
	}

}
