package CollectionFramework;

import java.util.*;



class StudentCollection{
	
	int age;
	String address;
	String name;
	
	StudentCollection(int age,String address,String name){
		this.age=age;
		this.address=address;
		this.name=name;
	}
	
}
public class ArrayListDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentCollection obj1= new StudentCollection(12,"Thane","soham");
		StudentCollection obj2 = new StudentCollection(13,"Kalyan","Raju");
		
		ArrayList <StudentCollection>a1 = new ArrayList<StudentCollection>();
		a1.add(obj1);
		a1.add(obj2);
		 
		System.out.println("Elements are as follows");
		
		Iterator<StudentCollection> itr=a1.iterator();
		
		while(itr.hasNext()) {
		StudentCollection ob3=itr.next();
		System.out.println("age is"+ob3.age);
		System.out.println("address is"+ob3.address);
		System.out.println("name is"+ob3.name);

	}
	}
}
