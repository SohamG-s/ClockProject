package CollectionFramework;
import java.util.*;
public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<String> o= new LinkedHashSet<String>();
		o.add("Store");
		o.add("HHII");
		o.add("Store");
		Iterator<String> o1 = o.iterator() ;
		while(o1.hasNext()){
			System.out.println(o1.next());
		}
		
	}

}
