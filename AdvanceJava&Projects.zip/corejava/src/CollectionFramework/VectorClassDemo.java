package CollectionFramework;
import java.util.*;
public class VectorClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Object>o1 = new Vector<Object>();//using object type(object is a base class for all classes using it as a type we can store any elements[ int ,double,long..etc]
		System.out.println(" Default Capacity  of vector is "+o1.capacity());
		System.out.println("Size of Vector is "+o1.size());
		o1.add(1);
		o1.addElement(12);
		System.out.println("After adding 2 elements "+o1.size());

		Enumeration<Object>o2=o1.elements();
		while(o2.hasMoreElements()) {
			System.out.println(o2.nextElement());
			
		
	}

	}}
