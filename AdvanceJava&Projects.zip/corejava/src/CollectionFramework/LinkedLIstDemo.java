package CollectionFramework;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedLIstDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer>a1= new LinkedList();
		a1.add(4);
		a1.add(3);
		a1.add(2);
		a1.add(1);

		ListIterator<Integer>ltr = a1.listIterator();
		
		while(ltr.hasNext()) {
			System.out.print(ltr.next()+" ");
		}
		
		System.out.println("Spaceeeeee");
		while(ltr.hasPrevious()) {
			System.out.print(ltr.previous()+" ");
		}
	}	

}
