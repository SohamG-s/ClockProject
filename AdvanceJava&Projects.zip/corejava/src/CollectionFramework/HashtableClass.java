package CollectionFramework;
import java.util.*;
public class HashtableClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Hashtable<Integer,String>o1 = new Hashtable<Integer,String>();
		 
		 o1.put(1,"Soham");
		 o1.put(2, "Sandy");
		 o1.put(3, "Rahul");
		 
		 System.out.println("Elements are as follows");
		 
		 for(Map.Entry<Integer, String>o2 : o1.entrySet()) {
			 System.out.println(o2.getKey()+o2.getValue());
		 }
				 
	}

}
