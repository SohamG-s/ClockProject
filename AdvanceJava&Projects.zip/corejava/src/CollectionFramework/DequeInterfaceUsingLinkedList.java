package CollectionFramework;
import java.util.*;
public class DequeInterfaceUsingLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<String>o = new LinkedList();
		
		 Deque<String> deque = new LinkedList<>();

	        // Add elements to the deque
	        deque.addFirst("1");
	        deque.addFirst("2");
	        deque.addFirst("3");
	        deque.addFirst("4");
	        deque.addLast("6");
	        deque.offerFirst("Soham");
	        deque.offerLast("Sakpal");

	        // Access elements from the deque
	        System.out.println("First Element: " + deque.getFirst()); // Soham
	        System.out.println("Last Element: " + deque.getLast());   // Sakpal

	        // Peek elements from the deque
	        System.out.println("Peek First Element: " + deque.peekFirst()); // Soham
	        System.out.println("Peek Last Element: " + deque.peekLast());   // Sakpal

	        // Remove elements from the deque
	        System.out.println("Removed First Element: " + deque.removeFirst()); // Soham
	        System.out.println("Removed Last Element: " + deque.removeLast());   // Sakpal

	        // Poll elements from the deque
	        System.out.println("Polled First Element: " + deque.pollFirst());     // 4
	        System.out.println("Polled Last Element: " + deque.pollLast());  // 6

	        // Add and remove specific elements
	        deque.addFirst("5");
	        deque.remove("3");
	        deque.remove("4");

	        // Print the final state of the deque
	        System.out.println("Final Deque: " + deque);
	    }
	
	

}
