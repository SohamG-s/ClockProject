package CollectionFramework;
import java.util.*;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,String>o= new TreeMap<Integer,String>();
		
		o.put(1, "Soham");
		o.put(3, "Rahul");
		o.put(2, "Keshav");
		
		for(Map.Entry<Integer, String>o1: o.entrySet()) {
			System.out.println(o1.getValue()+o1.getKey());
		}
		
	}

}
