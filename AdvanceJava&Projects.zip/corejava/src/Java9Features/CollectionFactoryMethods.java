package Java9Features;

import java.util.*;

public class CollectionFactoryMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		List<Integer>o3 = List.of(1,2,3,4,5,6,7,8,9,0);//of(); is introduced in java 9
		for(Integer o4:o3 ) {
			System.out.println(o4);
		}
		
		Set<Integer>o5 = Set.of(1,2,3,4,5,6,7,8,9,0);//of(); is introduced in java 9
		for(Integer o6:o5) {
			System.out.println(o6);
		}
		
		Map<Integer, String>o7 = Map.of(1,"a",2,"b",3,"c") ;//of(); is introduced in java 9
		for(Map.Entry<Integer,String>mp:o7.entrySet()) {
			System.out.print(mp.getKey()+ mp.getValue());
		}
		
		Map.Entry<Integer,String>me= Map.entry(1,"java");
		Map.Entry<Integer,String>mt= Map.entry(2,"C");

		Map<Integer,String>oi = Map.ofEntries(me,mt);//ofEntries(); is introduced in java 9
		for(Map.Entry<Integer,String>mi:oi.entrySet()) {
			System.out.println(mi.getValue()+mi.getKey());
		}
		 
		
	}

}
