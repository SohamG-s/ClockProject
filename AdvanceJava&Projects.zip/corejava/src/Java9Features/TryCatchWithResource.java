package Java9Features;
import java.io.*;
public class TryCatchWithResource {

	public static void main(String[] args)throws FileNotFoundException {
		// TODO Auto-generated method stub
		File f1 = new File("abc.txt");
		FileOutputStream fos = new FileOutputStream(f1);
		DataOutputStream dos = new DataOutputStream(fos);
		try(dos){
			String msg = "Java hi";
			byte b[]=msg.getBytes();
			dos.write(b);
			System.out.println("File written");
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
