package Java9Features;
interface MyInterface {
    
    // Default methods that share common code
    default void methodOne() {
        System.out.println("Method One method");
        commonCode();
       // System.out.println("Common Code");//Avoiding this statement to write again 
    }

    default void methodTwo() {
        System.out.println("Method Two method");
        commonCode();
        // System.out.println("Common Code");//Avoiding this statement to write again 

    }

    // Private method to avoid code duplication
    private void commonCode() {
        System.out.println("Common Code method");
        
    }    
}

class Regularmethod implements MyInterface {
    // MyClass automatically gets the behavior of methodOne and methodTwo
}


public class UsingPrivateMethodInInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Regularmethod myClass = new Regularmethod();
	        myClass.methodOne();  // Outputs: Method One, Common Code
	        myClass.methodTwo();  // Outputs: Method Two, Common Code
	}

}
