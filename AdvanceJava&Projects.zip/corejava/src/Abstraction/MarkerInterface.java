package Abstraction;


interface bike {
	
}
interface car{
	
}

class Twowheel implements bike {
	public void get() {
		System.out.println("It is method of twowheel");
	}
	}

class Threewheel implements car{
	public void show() {
		System.out.println("It is method of threewheel");
}
}
public class MarkerInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Twowheel o1 = new Twowheel();
		o1.get();
		
		Threewheel o2 = new Threewheel();
 		o2.show();
	}

}
