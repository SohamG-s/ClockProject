package Abstraction;

class A {
    public void show() {
        System.out.println("Outer class");
    }
    
    // Non-static inner class
    class B {
        public void display() {
            System.out.println("Non-static inner class");
        }
    }
    
    // Static inner class
    static class F {
        public void get() {
            System.out.println("Static inner class");
        }
    }
}

class G {
    public void get4() {
        System.out.println("External class");
    }
}

public class StaticClassDemo {
    public static void main(String[] args) {
        // Creating an instance of outer class A
        A obj = new A();
        obj.show();
        
        // Creating an instance of external class G
        G g = new G();
        g.get4();
        
        // Creating an instance of non-static inner class B
        A.B objb = obj.new B();
        objb.display();
        
        
        // Creating an instance of static inner class F
        A.F staticInner = new A.F();
        staticInner.get();
        
        // Alternatively, you can call static inner class method directly
     //   A.F.get();
    }
}
