package Abstraction;

interface a{
	void show();
	
	interface b{
		void info();
	}
}
class NestedDemo implements a.b{
	public void show() {
		System.out.println("Implementation for a");
	}
	public void info() {
		System.out.println("Implementation for b");
	}
	public void get() {
		System.out.println("Method for NestedDemo");
	}
}
public class Nestednterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		NestedDemo o1 = new NestedDemo() ;
		o1.show();
		o1.info();
		o1.get();
		
	}

}
