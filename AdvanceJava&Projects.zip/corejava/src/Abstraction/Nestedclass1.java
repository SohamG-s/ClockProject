package Abstraction;
class A9{
	public void get() {
		System.out.println("A class");
	}
	class B{
		public void show() {
			System.out.println("B class ");
		}
	}
}
public class Nestedclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A9 obj = new A9 ();
		obj.get();
		
		A9.B o1 = obj.new B();
		o1.show();
		
	}

}
