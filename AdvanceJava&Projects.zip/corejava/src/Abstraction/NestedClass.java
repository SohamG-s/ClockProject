package Abstraction;
class Outer{
	public void get() {
		System.out.println("It is outer class a0");
	}
	class Inner extends Outer{
		public void show() {
			System.out.println("It is inner class b0");
		
	}
	}
}

public class NestedClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer  obj = new Outer();
		obj.get();
		
		Outer.Inner objb = obj.new Inner();
		objb.show();
		objb.get();
		
	}

}
