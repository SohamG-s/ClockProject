package Abstraction;

import java.util.Scanner;

abstract class Shape {
    public abstract void displayarea(); // abstract method

    public void display() {
        System.out.println("Non abstract display method of abstract class");
    }
}

class Square extends Shape {
    int area;

    Square(int side) {
        area = side * side;
    }

    public void displayarea() { 
        System.out.println("Area of square is " + area);
    }
}

class Rectangle extends Shape {
    int area;

    Rectangle(int length, int breadth) {
        area = length * breadth;
    }

    public void displayarea() {
        System.out.println("Area of rectangle is " + area);
    }
}

class Triangle extends Shape {
    double ar;

    Triangle(double base, int height) {
        ar = 0.5 * base * height;
    }

    public void displayarea() {
        System.out.println("Area of triangle is " + ar);
    }
}

class Circle extends Shape {
    double ar;

    Circle(double radius) {
        ar = 3.14 * radius * radius;
    }

    public void displayarea() {
        System.out.println("Area of circle is " + ar);
    }
}

public class AbstractionArea {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Square shape= new Square(1); 
        shape.display();

        System.out.println("Enter the side of the square:");
        int side = sc.nextInt();
        Square o1 = new Square(side);
        o1.displayarea();

        System.out.println("Enter the length and breadth of the rectangle:");
        int length = sc.nextInt();
        int breadth = sc.nextInt();
        Rectangle o2 = new Rectangle(length, breadth);
        o2.displayarea();

        System.out.println("Enter the base and height of the triangle:");
        double base = sc.nextDouble();
        int height = sc.nextInt();
        Triangle o3 = new Triangle(base, height);
        o3.displayarea();

        System.out.println("Enter the radius of the circle:");
        double radius = sc.nextDouble();
        Circle o4 = new Circle(radius);
        o4.displayarea();
        
        
        
        sc.close();
    }
}
