package Abstraction;

interface a1 {
	void get();
}
interface b {
	void show();
}
interface c extends a1,b{
	void display();
}

class Extended implements c{
	public void get() { 
		System.out.println("Implementation of a interface");
	}
	public void show() {
		System.out.println("Implementation of b interface");
	}
	public void display() {
		System.out.println("Implementation of c interface");
	}
}
public class ExtendedInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		c ref;
		
		ref = new Extended();
		ref.get();
		ref.show();
		ref.display();
	}

}
