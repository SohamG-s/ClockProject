package Abstraction;

interface abc{
	void show();
}
interface cd{
	void get();
}
class FunctionalInterfaceDemo implements abc,cd{
	public void show() {
		System.out.println("Implementation for interface abc");
	}
	public void get() {
		System.out.println("Implementation for interface cd");
	}
}
public class FunctionalInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		FunctionalInterfaceDemo o1 = new FunctionalInterfaceDemo();
		o1.show();
		o1.get();
	}

}
