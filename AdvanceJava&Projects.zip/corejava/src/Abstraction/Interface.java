package Abstraction;

class a6{
	public void normal() {
		System.out.println("normal");
	}
}
interface b6{
	void abnormal();
}
class c3 extends a6 implements b6 {
	public void abnormal() {
		System.out.println("abnormal");
	}
}
public class Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 c3 o1 = new c3();
		 o1.normal();
		 o1.abnormal();
			 
		 }
	}


