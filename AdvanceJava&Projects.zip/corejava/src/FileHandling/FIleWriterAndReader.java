package FileHandling;
import java.io.*;
import java.io.IOException;
public class FIleWriterAndReader{

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		File f = new File("WriteHead.txt");
		
		if(!f.exists()) {
			f.createNewFile();
			System.out.println("New File created");
		}
	else {
			System.out.println("File already Exist");
		}
		
	FileWriter fw = new FileWriter(f);
		fw.write(30);// can handle only integer and strings
		fw.write("\nI stay in Kalyan");
		fw.write("\nITs okay");
		fw.close();
		
		
		FileReader fr = new FileReader(f);
	int i;
		while((i=fr.read())!=-1){
			System.out.print ((char)i);
		}
		System.out.println(f);
		fr.close();
	}

}
