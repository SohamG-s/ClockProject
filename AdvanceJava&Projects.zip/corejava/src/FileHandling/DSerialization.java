package FileHandling;
import java.io.*;
public class DSerialization {

	public static void main(String[] args)throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		File f = new File("Serialization Interface.txt");		
			
		
			
		FileInputStream fis = new FileInputStream(f);
		ObjectInputStream ois = new ObjectInputStream(fis);
		Students d1 = (Students)ois.readObject();
	System.out.println("Student roll no "+d1.age);
	System.out.println("Student name "+d1.name);
	System.out.println("Student address "+d1.address);
ois.close();

	}

}
