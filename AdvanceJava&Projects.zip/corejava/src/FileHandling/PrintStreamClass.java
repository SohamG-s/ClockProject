package FileHandling;
import java.io.*;
public class PrintStreamClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		try {
			//File fi = new File("Stream.txt");
			PrintStream ps = new PrintStream("News.txt");
//			
//			if(!fi.exists()) 
//			{
//				fi.createNewFile();
//					System.out.println("New file created");
//				
//			} 
//			else
//			{
//				System.out.println("File already Exist");
//			}
			String msg = "File Name is PROTECTED";
			byte[]array=msg.getBytes();
			ps.write(array);
			ps.println(70);
			ps.print("This is StreamClass using file ");
			ps.println("hello everyone");
			int age =30;
			ps.printf("My age is %d%n",age);
			ps.print(9.0);
			
			ps.close();
	 
			
				
			
//		}
//		catch(Exception e) {
//			System.out.println(e);
//			
//			
//		}
		
		
	}

}
