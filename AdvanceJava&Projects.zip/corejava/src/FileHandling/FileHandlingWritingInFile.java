package FileHandling;
//import java.io.DataOutputStream;
import java.io.*;
//import java.io.FileOutputStream;
import java.io.IOException;
public class FileHandlingWritingInFile {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		File f = new File("Second.txt");
		
		if(!f.exists()) {
			f.createNewFile();
			System.out.println("New FIle created");
			 
		}else {
			System.out.println("FIle already exist");
		}
		String msg = "File Name is PROTECTED";
		byte[]array=msg.getBytes();
		
		FileOutputStream fos = new FileOutputStream(f);
		DataOutputStream dos = new DataOutputStream(fos);
		
		dos.write(array);
		System.out.println("Data written in file");
		dos.close();
	}

}
