package FileHandling;
import java.io.*;
public class UsingPrintWriterToWrite {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		File f = new File("PrintWriterFile.txt");
//		
//		if(!f.exists()) {
//			f.createNewFile();
//			System.out.println("File Created");
//		}
//		else {
//			System.out.println("File already exist");
//		}
//		
		PrintWriter pw = new PrintWriter("PrintWriterFile.txt");
		pw.print ("USing printWriter class");
		pw.println("THis is a class");
		int age= 30;
		pw.printf("MY age is %d%n" ,age );
		double u= 4.33;
		pw.printf("MY age is %f" ,u );
		long ph=1323233;
		pw.printf("\nMY age is %d",ph );

		pw.close();
		
		FileReader fr = new FileReader("PrintWriterFile.txt");
		int i;
		while((i=fr.read())!=-1) {
			System.out.print((char)i);
			
		}
		fr.close();
	}
}
