package FileHandling;
import java.io.*;

class Students implements Serializable{
	
	transient int age ;
	String name;
	String address;
	
	Students(int age,String name,String address){
		this.age=age;
		this.name=name;
		this.address=address;
		
	}

	@Override
	public String toString() {
		return "Students [age=" + age + ", name=" + name + ", address=" + address + "]";
	}
	
}
public class SerializationInterface {

	public static void main(String[] args) throws IOException {
		
		Students s1 = new Students(30,"Soham Sakpal","Thane" );
		File f = new File("Serialization Interface.txt");
		if(!f.exists()) {
			f.createNewFile();
			System.out.println("New File Created");
		}else {
			System.out.println("File already Exist");
		}
		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(s1);
		System.out.println("Serialization Done");
		
		
		oos.close();
		System.out.println(s1);
	}

}
