package FileHandling;
import java.io.*;
public class ReadingTheFile {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		
		File f = new File("Second.txt");
		
		
		
		
		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		
		int i;
		while((i=dis.read())!=-1){  // -1 means end of stream or the last data of file
			System.out.print((char)i);
			
		}
		dis.close();
		
	}

}
