package FileHandling;
import java.io.*;
import java.io.IOException;

public class FilesDemoCreateAndDeleteFile {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		File f = new File("Second.txt");
//	if(f.createNewFile()) {
//			System.out.println("New file created");
//		}else { 
//			System.out.println("File already exist");
//		}
	if(f.delete()) {
			System.out.println("File Deleted");
		}
	}

}
