package Polymorphism;
import java.util.Scanner;
class Shape{
	int area ;
	double ar;
	
	public void calculatearea(int side) {
	
		area = side*side;
		System.out.println("Area is "+area); 
	}
	public double calculatearea(double radius) {
		ar = 3.14*radius *radius;
		return ar;
	}
	public int calculatearea(int length, int breadth) {
		area = length *breadth;
		return area;
	}
	public void  calculatearea( double base,int height) {
		ar = base*height;
		
	}
}
public class MethodOverloading {

	public static void main(String[] args) {
		int s, l, b,  h;
		double ba, r;
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the side ");
		s= sc.nextInt();
		Shape o1 = new Shape();
		o1.calculatearea(s);
		
		
		System.out.println("Enter radius");
		r = sc.nextDouble();
		Shape o2 = new Shape();
		double c =o2.calculatearea(r);
		System.out.println("Area is " + c);
		
		
		System.out.println("Enter the length and breadth");
		l= sc.nextInt();
		b= sc.nextInt();
		Shape o3 = new Shape();
		int a =o3.calculatearea(l,b);
		System.out.println("Area is " + a);
		
		
		System.out.println("Enter base and height");
		ba= sc.nextDouble();
		h=sc.nextInt();
		Shape o4= new Shape();
		o4.calculatearea(ba,h);
		System.out.println("Area is " + o4.ar);
	}

}
