package Polymorphism;

class parent{
	public void display() {
		System.out.println("Base class display method");
	}
}
class Derived extends parent{
	public void display() {
		System.out.println("Derived class display method");
	}
}
class sub extends Derived{
	public void display() {
		System.out.println("sub class display method");
		
	}
}
class child extends sub{
	public void display() {
		System.out.println("child class display method");
	}
}
public class DynamicmethodDispatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		
	parent 	ref;
	 
	
	ref= new parent();
		ref.display();
		
		 ref= new Derived();
		ref.display();   
		
	ref = new sub(); 
		ref.display();
		
		ref = new child();
		ref.display();
	}

}
