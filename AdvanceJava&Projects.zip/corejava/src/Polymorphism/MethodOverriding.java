package Polymorphism;
import java.util.Scanner;
class AreaShape{
	public void displayarea() {
		System.out.println("base class area display method");
		}
}

class Rectangle {
	int area ;
    Rectangle (int length, int breadth){
    	area = length * breadth;
    	
    }
    public void displayarea() {
    	System.out.println("The area of Rectangle is "+area);
    }
	
}
class Square extends AreaShape{
	int area ;
	Square(int side){
		area = side*side;
		
		
	}
	public void displayarea () {
		System.out.println("The area of square is "+area);
		
	}
}
class Triangle extends AreaShape {
	double ar ;
	Triangle(double base, int height ){
		ar = 0.5 * base * height;
	}
	public void displayarea() {
		System.out.println("The area of triangle is "+ar);
	}
}
class Circle extends AreaShape{
	double ar;
	Circle (double radius){
		ar = 3.14 *radius *radius;
		
	}
	public void displayarea() {
		
	
	System.out.println("The area of cirlce is "+ar);
}
}
public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner (System.in);
int l,b,s,h;
double r,ba;

	System.out.println("Enter the length and breadth");
	l = sc.nextInt();
	b = sc.nextInt();
	Rectangle r1 = new Rectangle (l,b);
	r1.displayarea();
	
	
	System.out.println("Enter the side");
	s = sc.nextInt();
	Square s2 = new Square (s);
	s2.displayarea();
	
	System.out.println("ENter the base and height");
	ba = sc.nextDouble();
	h = sc.nextInt();
	Triangle t3 = new Triangle(ba,h);
	t3.displayarea();
	
	System.out.println("Enter the radius");
	r = sc.nextDouble();
	Circle c4 = new Circle(r);
	c4.displayarea();
	}

}
