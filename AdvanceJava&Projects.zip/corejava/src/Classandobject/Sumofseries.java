package Classandobject;
import java.util.Scanner;
public class Sumofseries {

	int i ,n,sum=0;
	Scanner sc = new Scanner (System.in);
	
	public void get() {
		System.out.println("Enter the limit of series");
		n=sc.nextInt();
	}
	
	public void display() {
		for(i=1;i<=n;i++) {
			sum=sum+i;
		}
		System.out.println("Sum of series of "+n+ "is "+sum );
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sumofseries obj = new Sumofseries();
		obj.get();
		obj.display();
	}

}
