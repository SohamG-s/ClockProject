package Classandobject;


class demo1{
	static int count;
	
	demo1(){
		count++;
		System.out.println("object created "+count);
		
	}
	protected void finalize() {
		System.out.println("Object Destroyed "+count);
		count--;
	}
	
}

public class GarbageCollector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		demo1 obj1 = new demo1();
		demo1 obj2 = new demo1();
		demo1 obj3 = new demo1();
		System.out.println("hashcode of object1: "+obj1.hashCode());
		System.out.println("hashcode of object2: "+obj2.hashCode());
		System.out.println("hashcode of object3: "+obj3.hashCode());
		obj1 = null;
		obj2 = null;
		obj3 = null;
		System.gc();
		
	}

}
