package Classandobject;


class Employee{
	String name;
	int id,age;
	double exp;
	long salary;
	

}
public class Objectarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		Employee e1 = new Employee() ;
			e1.name = "Rakesh";
			e1.age = 14;
			e1.id = 22;
			e1.exp=2.4;
			e1.salary=34000;
		
			Employee e2= new Employee();
		        e2.name="Raju";
				e2.age=34;
				e2.id= 333;
				e2.exp=3.4;
				e2.salary=43000;
		
	Employee emp[] = new Employee[2];
	emp[0]=e1;
	emp[1]=e2;
	System.out.println("Employee details are as follows");
	System.out.println(" name "+" age "+" id "+" exp "+" salary ");
	for(i=0;i<emp.length;i++) {
		System.out.println(emp[i].name+" "+emp[i].age+" "+emp[i].id+emp[i].exp+" "+emp[i].salary);
	}
	}
	}
	
	
	


