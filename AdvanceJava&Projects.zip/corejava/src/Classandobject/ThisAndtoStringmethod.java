package Classandobject;


class This1{
	int rno,age;
	String name;
	
	public void get(int rno,int age,String name) {
		this.rno=rno;
		this.age=age;
		this.name=name;
		
	}
	public void show() {
		System.out.println("Rollno is "+rno);
		System.out.println("Age is "+age);
		System.out.println("Name is "+name);
	}
	public String toString() {
		return"On the way";
	}
	
}


public class ThisAndtoStringmethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	This1 obj = new This1();
	obj.get(1,20,"soham");
	obj.show();
	System.out.println(obj);
	}

}
