package Classandobject;

class Demo{
	
	static int num = 5;
	
	public static void show() {
		System.out.println("Say hi");
		System.out.println("Say "+num );
		count();
	}
	public static void count() {
		num++;
		System.out.println("Say");
		System.out.println("Say "+num);
		
	}
	
	static {
		System.out.println("Say");
	}
	static {
		System.out.println("suee");
	}
}



public class StaticKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Demo.show();
			
		}

	}


