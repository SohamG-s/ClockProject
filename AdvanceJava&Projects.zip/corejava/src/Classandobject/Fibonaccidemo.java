package Classandobject;
import java.util.Scanner;
class Fibonacci{
	int i,n,a=0,b=1,c=1;
	Scanner sc = new Scanner(System.in);
public void getinfo() {
	System.out.println("Enter the limit for fibonacci");
	n=sc.nextInt();
}
public void display() {
	for(i=1;i<=n;i++) {
		
		System.out.println(c);
		c = a+b;
		a=b;
		b=c;
		
	}
}




}




public class Fibonaccidemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Fibonacci obj = new Fibonacci();
obj.getinfo();
obj.display();

	}

}
