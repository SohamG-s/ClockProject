package Classandobject;
import java.util.Scanner;


class Reverse1{
	int i,n,t;
	Scanner sc = new Scanner(System.in);
	public void get() {
		System.out.println("Enter the number");
		n=sc.nextInt();
}
	public void display() {
		while(n!=0) {
			t=n%10;
			System.out.print(t);
			n=n/10;
		}
		
	}
}

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Reverse1 obj = new Reverse1();
obj.get();
obj.display(); 


	}

}
