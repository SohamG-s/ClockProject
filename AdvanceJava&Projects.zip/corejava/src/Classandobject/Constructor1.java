package Classandobject;
import java.util.Scanner;
class Shape1{
	int area;
	double ar;
	
	Shape1(){
		System.out.println("Default constructor called");
	}
	Shape1(int side){
		
		area=side*side;
		System.out.println("Area of square"+area);
	}
	Shape1(double radius){
		ar = 3.14*radius *radius;
		System.out.println("Area of circle"+ar);
	}
	Shape1(int length,int breadth){
		area= length *breadth;
		System.out.println("area of rectangle"+area);
	}
	Shape1(double base ,int height){
		
		ar=0.5*base*height;
		System.out.println("area of triangle"+ar);
		
	}
	Shape1(Shape1 s2){
		System.out.println("Copy constructor called ");
		
	}
	
}
public class Constructor1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s,h,l,b;
		double ba,r;
		
		Scanner sc= new Scanner (System.in);
			Shape1 s1= new Shape1();
			
			System.out.println("Enter the side of square");
			s= sc.nextInt();
			Shape1 s2 = new Shape1(s);
			
			System.out.println("Enter the radius of circle");
			r = sc.nextDouble();
			Shape1 s3 = new Shape1(r);
			
			System.out.println("Enter the radius of rectangle");
			l= sc.nextInt();
			b=sc.nextInt();
			Shape1 s4 = new Shape1(l,b);
			
			System.out.println("Enter the radius of triangle");
			ba = sc.nextInt();
			h= sc.nextInt();
			Shape1 s5 = new Shape1(ba,h);
			
			Shape1 s6 = new Shape1(s1);
			
			
		}
	}


