package Classandobject;
import java.util.Scanner;

class Factorial1{
	int i,n,fact=1;
	Scanner sc = new Scanner (System.in);
	
	public void get() {
		System.out.println("Enter the input");
		n=sc.nextInt();
	}
	
	public void show()
	{
		System.out.println("the factorial for "+n+ " is ");
		for(i=n;i>=1;i--) {
			fact =fact * i;
		}
		System.out.println(fact);
	}
}
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Factorial1 obj = new Factorial1();
		obj.get();
		obj.show();
	}

}
